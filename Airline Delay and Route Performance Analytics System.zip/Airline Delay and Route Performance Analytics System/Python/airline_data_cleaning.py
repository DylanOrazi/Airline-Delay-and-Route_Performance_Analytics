from pathlib import Path

import pandas as pd

# ============================================================
# PROJECT PATHS
# ============================================================

SCRIPT_FOLDER = Path(__file__).resolve().parent
PROJECT_FOLDER = SCRIPT_FOLDER.parent

RAW_DATA_FOLDER = PROJECT_FOLDER / "Data" / "Raw"
CLEANED_DATA_FOLDER = PROJECT_FOLDER / "Data" / "Cleaned"

RAW_FILE = (
    RAW_DATA_FOLDER
    / "Airline_Delay_and_Route_Performance_8000_Raw_Flights.xlsx"
)

# ============================================================
# LOAD RAW FLIGHT DATA
# ============================================================

def load_raw_flight_data(file_path: Path) -> pd.DataFrame:
    """Load the Raw_Flights worksheet from the Excel workbook."""

    if not file_path.exists():
        raise FileNotFoundError(
            f"Raw workbook was not found:\n{file_path}"
        )

    flight_data = pd.read_excel( 
        file_path,
        sheet_name="Raw_Flights",
        engine="openpyxl"
    )

    return flight_data

# ============================================================
# DISPLAY INITIAL DATA PROFILE
# ============================================================

def display_initial_profile(flight_data: pd.DataFrame) -> None:
    """Display the initial structure and quality of the raw data."""

    print("=" * 70)
    print("AIRLINE DELAY AND ROUTE PERFORMANCE DATA CLEANING")
    print("=" * 70)

    print("\nRaw DATASET SIZE")
    print("-" * 70)
    print(f"Rows: {flight_data.shape[0]:,}")
    print(f"Columns: {flight_data.shape[1]:,}")

    print("\nCOLUMN NAMES")
    print("-" * 70)

    for column_number, column_name in enumerate(
        flight_data.columns,
        start=1
    ):
        print(f"{column_number:>2}. {column_name}")

    print("\nDATA TYPES")
    print("-" * 70)
    print(flight_data.dtypes.to_string())

    print("\nMISSING VALUES BY COLUMN")
    print("-" * 70)

    missing_values = (
        flight_data.isna()
        .sum()
        .sort_values(ascending=False)

    )

    missing_values = missing_values[
        missing_values > 0
    ]

    if missing_values.empty:
        print("No missing values were detected.")
    else:
        print(missing_values.to_string())

    print("\nCOMPLETE DUPLICATE ROWS")
    print("-" * 70)

    duplicate_count = flight_data.duplicated().sum()

    print(f"Duplicate rows detected: {duplicate_count:,}")

    print("\nFIRST FIVE RECORDS")
    print("-" * 70)
    print(flight_data.head().to_string(index=False))

# ============================================================
# REMOVE DUPLICATE FLIGHT RECORDS
# ============================================================

def remove_duplicate_records(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Remove complete duplicate rows from the flight dataset."""

    duplicate_count_before = flight_data.duplicated().sum()
    row_count_before = len(flight_data)

    cleaned_data = (
        flight_data
        .drop_duplicates()
        .reset_index(drop=True)
    )

    duplicate_count_after = cleaned_data.duplicated().sum()
    row_count_after = len(cleaned_data)
    rows_removed = row_count_before - row_count_after

    print("\nDUPLICATE REMOVAL")
    print("-" * 70)
    print(
        f"Rows before duplicate removal: "
        f"{row_count_before:,}"
    )
    print(
        f"Duplicate rows detected: "
        f"{duplicate_count_before:,}"
    )
    print(
        f"Duplicate rows removed: "
        f"{rows_removed:,}"
    )
    print(
        f"Rows after duplicate removal: "
        f"{row_count_after:,}"
    )
    print(
        f"Duplicates remaining: "
        f"{duplicate_count_after:,}"
    )

    return cleaned_data

# ============================================================
# STANDARDIZE AIRLINE NAMES
# ============================================================

def standardize_airline_names(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Standardize airline names using the airline code."""

    airline_name_map = {
        "AA": "American Airlines",
        "DL": "Delta Air Lines",
        "UA": "United Airlines",
        "WN": "Southwest Airlines",
        "B6": "JetBlue Aurlines",
        "AS": "Alaska Airlines",
        "NK": "Spirit Airlines",
        "F9": "Frontier Airlines",
        "G4": "Allegiant Air",
        "HA": "Hawaiian Airlines"
    }

    cleaned_data = flight_data.copy()

    original_names = cleaned_data[
        [
            "Airline_Code",
            "Airline_Name"
        ]
    ].copy()

    cleaned_data["Airline_Code"] = (
        cleaned_data["Airline_Code"]
        .astype("string")
        .str.strip()
        .str.upper()
    )

    cleaned_data["Airline_Name"] = (
        cleaned_data["Airline_Code"]
        .map(airline_name_map)
        .fillna(cleaned_data["Airline_Name"])
    )

    changed_name_count = (
        original_names["Airline_Name"]
        .astype("string")
        .fillna("Missing")
        !=
        cleaned_data["Airline_Name"]
        .astype("string")
        .fillna("Missing")
    ).sum()

    unknown_airline_codes = sorted(
        cleaned_data.loc[
            ~cleaned_data["Airline_Code"].isin(
                airline_name_map.keys()
            ),
            "Airline_Code"
        ]
        .dropna()
        .unique()
        .tolist()
    )

    print("\nAIRLINE NAME STANDARDIZATION")
    print("-" * 70)

    print(
        f"Airline names corrected: "
        f"{changed_name_count:,}"
    )

    print(
        f"Standard airline code recognized: "
        f"{cleaned_data['Airline_Code'].isin(airline_name_map).sum():,}"
    )

    if unknown_airline_codes:
        print(
            "Unknown airline codes found: "
            + ", ".join(unknown_airline_codes)

        )
    else:
        print("Unknown airline codes found: 0")

    print("\nSTANDARDIZED AIRLINES")
    print("-" * 70)

    standardized_airlines = (
        cleaned_data[
            [
                "Airline_Code",
                "Airline_Name"
            ]
        ]
        .drop_duplicates()
        .sort_values("Airline_Code")
    )

    print(
        standardized_airlines.to_string(
            index=False
        )
    )

    return cleaned_data

# ============================================================
# HANDLE MISSING LOCATION AND SOURCE VALUES
# ============================================================

def handle_missing_location_and_source_values(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Fill missing location and data-source values."""

    airport_reference = {
        "ATL": {
            "City": "Atlanta",
            "State": "GA"
        },
        "DFW": {
            "City": "Dallas-Fort Worth",
            "State": "TX"
        },
        "DEN": {
            "City": "Denver",
            "State": "CO"
        },
        "ORD": {
            "City": "Chicago",
            "State": "IL"
        },
        "LAX": {
            "City": "Los Angeles",
            "State": "CA"
        },
        "JFK": {
            "City": "New York",
            "State": "NY"
        },
        "MIA": {
            "City": "Miami",
            "State": "FL"
        },
        "FLL": {
            "City": "Fort Lauderdale",
            "State": "FL"
        },
        "SEA": {
            "City": "Seattle",
            "State": "WA"
        },
        "SFO": {
            "City": "San Francisco",
            "State": "CA"
        },
        "LAS": {
            "City": "Las Vegas",
            "State": "NV"
        },
        "PHX": {
            "City": "Phoenix",
            "State": "AZ"
        },
        "CLT": {
            "City": "Charlotte",
            "State": "NC"
        },
        "MCO": {
            "City": "Orlando",
            "State": "FL"
        },
        "BOS": {
            "City": "Boston",
            "State": "MA"
        },
        "MSP": {
            "City": "Minneapolis",
            "State": "MN"
        },
        "DTW": {
            "City": "Detroit",
            "State": "MI"
        },
        "IAH": {
            "City": "Houston",
            "State": "TX"
        },
        "EWR": {
            "City": "Newark",
            "State": "NJ"
        },
        "PHL": {
            "City": "Philadelphia",
            "State": "PA"
        },
        "BWI": {
            "City": "Baltimore",
            "State": "MD"
        },
        "SAN": {
            "City": "San Diego",
            "State": "CA"
        },
        "TPA": {
            "City": "Tampa",
            "State": "FL"
        },
        "AUS": {
            "City": "Austin",
            "State": "TX"
        },
        "SLC": {
            "City": "Salt Lake City",
            "State": "UT"
        }
    }

    cleaned_data = flight_data.copy()

    origin_city_missing_before = (
        cleaned_data["Origin_City"]
        .isna()
        .sum()
    )

    destination_state_missing_before = (
        cleaned_data["Destination_State"]
        .isna()
        .sum()
    )

    data_source_missing_before = (
        cleaned_data["Data_Source"]
        .isna()
        .sum()
    )

    origin_city_map = {
        airport_code: airport_details["City"]
        for airport_code, airport_details
        in airport_reference.items()
    }

    destination_state_map = {
        airport_code: airport_details["State"]
        for airport_code, airport_details
        in airport_reference.items()
    }

    cleaned_data["Origin_City"] = (
        cleaned_data["Origin_City"]
        .fillna(
            cleaned_data["Origin_Airport"]
            .map(origin_city_map)
        )
    )

    cleaned_data["Destination_State"] = (
        cleaned_data["Destination_State"]
        .fillna(
            cleaned_data["Destination_Airport"]
            .map(destination_state_map)
        )
    )

    cleaned_data["Data_Source"] = (
        cleaned_data["Data_Source"]
        .fillna("Synthetic portfolio dataset")
    )

    origin_city_missing_after = (
        cleaned_data["Origin_City"]
        .isna()
        .sum()
    )

    destination_state_missing_after = (
        cleaned_data["Destination_State"]
        .isna()
        .sum()
    )

    data_source_missing_after = (
        cleaned_data["Data_Source"]
        .isna()
        .sum()
    )

    origin_cities_filled = (
        origin_city_missing_before
        - origin_city_missing_after
    )

    destination_states_filled = (
        destination_state_missing_before
        - destination_state_missing_after
    )

    data_sources_filled = (
        data_source_missing_before
        - data_source_missing_after
    )

    print("\nMISSING LOCATION AND SOURCE VALUES")
    print("-" * 70)

    print(
        f"Missing origin cities before: "
        f"{origin_city_missing_before:,}"
    )

    print(
        f"Origin cities filled: "
        f"{origin_cities_filled:,}"
    )

    print(
        f"Missing origin cities after: "
        f"{origin_city_missing_after:,}"
    )

    print()

    print(
        f"Missing destination states before: "
        f"{destination_state_missing_before:,}"
    )

    print(
        f"Destination states filled: "
        f"{destination_states_filled:,}"
    )

    print(
        f"Missing destination states after: "
        f"{destination_state_missing_after:,}"
    )

    print()

    print(
        f"Missing data-source values before: "
        f"{data_source_missing_before:,}"
    )

    print(
        f"Data-source values filled: "
        f"{data_sources_filled:,}"
    )

    print(
        f"Missing data-source values after: "
        f"{data_source_missing_after:,}"
    )

    return cleaned_data

# ============================================================
# VALIDATE AIRPORT CODES
# ============================================================

def validate_airport_codes(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Standardize and validate origin and destination airport codes."""

    valid_airport_codes = {
        "ATL",
        "DFW",
        "DEN",
        "ORD",
        "LAX",
        "JFK",
        "MIA",
        "FLL",
        "SEA",
        "SFO",
        "LAS",
        "PHX",
        "CLT",
        "MCO",
        "BOS",
        "MSP",
        "DTW",
        "IAH",
        "EWR",
        "PHL",
        "BWI",
        "SAN",
        "TPA",
        "AUS",
        "SLC"
    }

    cleaned_data = flight_data.copy()

    cleaned_data["Origin_Airport"] = (
        cleaned_data["Origin_Airport"]
        .astype("string")
        .str.strip()
        .str.upper()
    )

    cleaned_data["Destination_Airport"] = (
        cleaned_data["Destination_Airport"]
        .astype("string")
        .str.strip()
        .str.upper()
    )

    cleaned_data["Origin_Airport_Valid"] = (
        cleaned_data["Origin_Airport"]
        .isin(valid_airport_codes)
    )

    cleaned_data["Destination_Airport_Valid"] = (
        cleaned_data["Destination_Airport"]
        .isin(valid_airport_codes)
    )

    invalid_origin_codes = sorted(
        cleaned_data.loc[
            ~cleaned_data["Origin_Airport_Valid"],
            "Origin_Airport"
        ]
        .dropna()
        .unique()
        .tolist()
    )

    invalid_destination_codes = sorted(
        cleaned_data.loc[
            ~cleaned_data["Destination_Airport_Valid"],
            "Destination_Airport"
        ]
        .dropna()
        .unique()
        .tolist()
    )

    invalid_origin_record_count = (
        ~cleaned_data["Origin_Airport_Valid"]
    ).sum()

    invalid_destination_record_count = (
        ~cleaned_data["Destination_Airport_Valid"]
    ).sum()

    cleaned_data["Origin_City"] = (
        cleaned_data["Origin_City"]
        .fillna("Unknown")
    )

    cleaned_data["Route"] = (
        cleaned_data["Origin_Airport"]
        + "-"
        + cleaned_data["Destination_Airport"]
    )

    cleaned_data["Route_Valid"] = (
        cleaned_data["Origin_Airport_Valid"]
        &
        cleaned_data["Destination_Airport_Valid"]
    )

    invalid_route_count = (
        ~cleaned_data["Route_Valid"]
    ).sum()

    print("\nAIRPORT CODE VALIDATION")
    print("-" * 70)

    print(
        f"Invalid origin-airport records: "
        f"{invalid_origin_record_count:,}"
    )

    if invalid_origin_codes:
        print(
            "Invalid origin codes found: "
            + ", ".join(invalid_origin_codes)
        )
    else:
        print("Invalid origin codes found: 0")

    print()

    print(
        f"Invalid destination-airport records: "
        f"{invalid_destination_record_count:,}" 
    )

    if invalid_destination_codes:
        print(
            "Invalid destination codes found: "
            + ", ".join(invalid_destination_codes)
        )
    else:
        print("Invalid destination codes found: 0")

    print()

    print(
        f"Routes requiring review: "
        f"{invalid_route_count:,}"
    )

    print(
        f"Missing origin cities remaining: "
        f"{cleaned_data['Origin_City'].isna().sum():,}"
    )

    return cleaned_data

# ============================================================
# STANDARDIZE CANCELLATION CODES
# ============================================================

def standardize_cancellation_codes(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Standardize cancellation codes and add readable reasons."""

    cancellation_code_map = {
        "A": "Carrier",
        "B": "Weather",
        "C": "National Airspace System",
        "D": "Security"
    }

    cancellation_text_to_code = {
        "CARRIER": "A",
        "WEATHER": "B",
        "NAS": "C",
        "NATIONAL AIRSPACE SYSTEM": "C",
        "SECURITY": "D"
    }

    cleaned_data = flight_data.copy()

    cleaned_data["Cancelled"] = (
        pd.to_numeric(
            cleaned_data["Cancelled"],
            errors="coerce"
        )
        .fillna(0)
        .astype(int)
    )

    original_codes = (
        cleaned_data["Cancellation_Code"]
        .astype("string")
        .copy()
    )

    cleaned_data["Cancellation_Code"] = (
        cleaned_data["Cancellation_Code"]
        .astype("string")
        .str.strip()
        .str.upper()
    )

    cleaned_data["Cancellation_Code"] = (
        cleaned_data["Cancellation_Code"]
        .replace(cancellation_text_to_code)
    )

    not_cancelled_mask = (
        cleaned_data["Cancelled"] == 0
    )

    cleaned_data.loc[
        not_cancelled_mask,
        "Cancellation_Code"
    ] = pd.NA

    valid_cancellation_codes = {
        "A",
        "B",
        "C",
        "D",
    }

    cancelled_mask = (
        cleaned_data["Cancelled"] == 1
    )

    invalid_cancelled_code_mask = (
        cancelled_mask
        &
        ~cleaned_data["Cancellation_Code"].isin(
            valid_cancellation_codes
        )
    )

    cleaned_data["Cancellation_Code_Valid"] = (
        ~cancelled_mask
        |
        cleaned_data["Cancellation_Code"].isin(
            valid_cancellation_codes
        )
    )

    cleaned_data["Cancellation_Reason"] = (
        cleaned_data["Cancellation_Code"]
        .map(cancellation_code_map)
    )

    cleaned_data.loc[
        not_cancelled_mask,
        "Cancellation_Reason"
    ] = "Not Cancelled"

    cleaned_data.loc[
        invalid_cancelled_code_mask,
        "Cancellation_Reason"
    ] = "Unknown"

    changed_code_count = (
        original_codes.fillna("Missing")
        !=
        cleaned_data["Cancellation_Code"]
        .astype("string")
        .fillna("Missing")
    ).sum()

    cancelled_flight_count = (
        cancelled_mask.sum()
    )

    valid_cancelled_code_count = (
        cancelled_mask
        &
        cleaned_data["Cancellation_Code"].isin(
            valid_cancellation_codes
        )
    ).sum()

    invalid_cancelled_code_count = (
        invalid_cancelled_code_mask.sum()
    )

    non_cancelled_with_code_count = (
        not_cancelled_mask
        &
        cleaned_data["Cancellation_Code"].notna()
    ).sum()

    print("\nCANCELLATION CODE STANDARDIZATION")
    print("-" * 70)

    print(
        f"Cancelled flights detected: "
        f"{cancelled_flight_count:,}"
    )

    print(
        f"Cancellation_code values changed: "
        f"{changed_code_count:,}"
    )

    print(
        f"Cancelled flights with valid codes: "
        f"{valid_cancelled_code_count:,}"
    )

    print(
        f"Cancelled flights requiring review: "
        f"{invalid_cancelled_code_count:,}"
    )

    print(
        f"Non-cancelled flights with codes remaining: "
        f"{non_cancelled_with_code_count:,}"
    )

    print("\nSTANDARD CANCELLATION REASONS")
    print("-" * 70)

    for code, reason in cancellation_code_map.items():
        print(f"{code}: {reason}")

    return cleaned_data

# ============================================================
# REVIEW AND FLAG DELAY OUTLIERS
# ============================================================

def flag_delay_outliers(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Identify suspicious departureand arrival delay values."""

    cleaned_data = flight_data.copy()

    early_delay_threshold = -90
    late_delay_threshold = 360

    cleaned_data["Departure_Delay_Minutes"] = (
        pd.to_numeric(
            cleaned_data["Departure_Delay_Minutes"],
            errors="coerce"
        )
    )

    cleaned_data["Arrival_Delay_Minutes"] = (
        pd.to_numeric(
            cleaned_data["Arrival_Delay_Minutes"],
            errors="coerce"
        )
    )

    departure_extreme_early = (
        cleaned_data["Departure_Delay_Minutes"]
        < early_delay_threshold
    )

    departure_extreme_late = (
        cleaned_data["Departure_Delay_Minutes"]
        > late_delay_threshold
    )

    arrival_extreme_early = (
        cleaned_data["Arrival_Delay_Minutes"]
        < early_delay_threshold
    )

    arrival_extreme_late = (
        cleaned_data["Arrival_Delay_Minutes"]
        > late_delay_threshold
    )

    cleaned_data["Departure_Delay_Outlier"] = (
        departure_extreme_early
        |
        departure_extreme_late
    )

    cleaned_data["Arrival_Delay_Outlier"] = (
        arrival_extreme_early
        |
        arrival_extreme_late
    )

    cleaned_data["Delay_Outlier_Flag"] = (
        cleaned_data["Departure_Delay_Outlier"]
        |
        cleaned_data["Arrival_Delay_Outlier"]
    )

    cleaned_data["Delay_Outlier_Reason"] = (
        "Within expected range"
    )

    cancelled_mask = (
        cleaned_data["Cancelled"] == 1
    )

    departure_only_mask = (
        cleaned_data["Departure_Delay_Outlier"]
        &
        ~cleaned_data["Arrival_Delay_Outlier"]
    )

    arrival_only_mask = (
        ~cleaned_data["Departure_Delay_Outlier"]
        &
        cleaned_data["Arrival_Delay_Outlier"]
    )

    both_delay_outliers_mask = (
        cleaned_data["Departure_Delay_Outlier"]
        &
        cleaned_data["Arrival_Delay_Outlier"]
    )

    cleaned_data.loc[
        departure_only_mask,
        "Delay_Outlier_Reason"
    ] = "Departure delay requires review"

    cleaned_data.loc[
        arrival_only_mask,
        "Delay_Outlier_Reason"
    ] = "Arrival delay requires review"

    cleaned_data.loc[
        both_delay_outliers_mask,
        "Delay_Outlier_Reason"
    ] = "Departure and arrival delays requires review"

    cleaned_data.loc[
        cancelled_mask,
        "Delay_Outlier_Reason"
    ] = "Not applicable - cancelled flight"

    departure_outlier_count = (
        cleaned_data["Departure_Delay_Outlier"]
        .sum()
    )

    arrival_outlier_count = (
        cleaned_data["Arrival_Delay_Outlier"]
        .sum()
    )

    total_outlier_record_count = (
        cleaned_data["Delay_Outlier_Flag"]
        .sum()
    )

    suspicious_departure_values = sorted(
        cleaned_data.loc[
            cleaned_data["Departure_Delay_Outlier"],
            "Departure_Delay_Minutes"
        ]
        .dropna()
        .unique()
        .tolist()
    )

    suspicious_arrival_values = sorted(
        cleaned_data.loc[
            cleaned_data["Arrival_Delay_Outlier"],
            "Arrival_Delay_Minutes"
        ]
        .dropna()
        .unique()
        .tolist()
    )

    print("\nDELAY OUTLIER REVIEW")
    print("-" * 70)

    print(
        f"Early_delay threshold: "
        f"less than {early_delay_threshold} minutes"
    )

    print(
        f"Late-delay threshold: "
        f"less than {late_delay_threshold} minutes"
    )

    print()

    print(
        f"Departure-delay outliers detected: "
        f"{departure_outlier_count:,}"
    )

    print(
        f"Arrival-delay outliers detected: "
        f"{arrival_outlier_count:,}"
    )

    print(
        f"Total records requiring delay review : "
        f"{total_outlier_record_count:,}"
    )

    print()

    if suspicious_departure_values:
        print(
            "Suspicious departure-delay vales: "
            + ", ".join(
                str(value)
                for value in suspicious_departure_values
            )
        )
    else:
        print("Suspicious departure-delay values: 0")

    print(
        "\nOutlier records were flagged but not removed."
    )

    return cleaned_data

# ============================================================
# CONVERT A SINGLE HHMM VALUE
# ============================================================

def convert_hhmm_value(value: object) -> object:
    """Convert an HHMM value into an HH:MM text value."""

    if pd.isna(value):
        return pd.NA

    try:
        numeric_value = int(float(value))
    except (TypeError, ValueError):
        return pd.NA

    hour = numeric_value // 100
    minute = numeric_value // 100

    if hour < 0 or hour > 23:
        return pd.NA

    if minute < 0 or minute > 59:
        return pd.NA

    return f"{hour:02d}:{minute:02d}"

# ============================================================
# CONVERT HHMM FIELDS INTO USABLE TIME VALUES
# ============================================================

def convert_hhmm_fields(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Convert scheduled and actual HHMM fields into HH:MM values."""

    cleaned_data = flight_data.copy()

    time_column_map = {
        "Scheduled_Departure": "Scheduled_Departure_Time",
        "Actual_Departure": "Actual_Departure_Time",
        "Scheduled_Arrival": "Scheduled_Arrival_Time",
        "Actual_Arrival": "Actual_Arrival_Time"
    }

    print("\nHHMM TIME CONVERSION")
    print("-" * 70)

    for source_column, new_column in time_column_map.items():
        cleaned_data[new_column] = (
            cleaned_data[source_column]
            .apply(convert_hhmm_value)
            .astype("string")
        )

        converted_count = (
            cleaned_data[new_column]
            .notna()
            .sum()
        )

        missing_count = (
            cleaned_data[new_column]
            .isna()
            .sum()
        )

        print(
            f"{new_column}: "
            f"{converted_count:,} converted, "
            f"{missing_count:,} missing"
        )

    cancelled_mask = (
        cleaned_data["Cancelled"] == 1
    )

    cancelled_with_actual_departure = (
        cancelled_mask
        &
        cleaned_data["Actual_Departure_Time"].notna()
    ).sum()

    cancelled_with_actual_arrival = (
        cancelled_mask
        &
        cleaned_data["Actual_Arrival_Time"].notna()
    ).sum()

    print()

    print(
        "Cancelled flights with an actual departure time: "
        f"{cancelled_with_actual_departure:,}"
    )

    print(
        "Cancelled flights with an actual arrival time: "
        f"{cancelled_with_actual_arrival:,}"
    )

    print(
        "\nBlank actual times for cancelled flights are expected."
    )

    return cleaned_data

# ============================================================
# ADD ANALYTICAL COLUMNS
# ============================================================

def add_analytical_columns(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Create analytical fields for SQL and Power BI reporting."""

    cleaned_data = flight_data.copy()

    arrival_delay = pd.to_numeric(
        cleaned_data["Arrival_Delay_Minutes"],
        errors="coerce"
    )

    cancelled_mask = (
        cleaned_data["Cancelled"] == 1
    )

    diverted_mask = (
        cleaned_data["Diverted"] == 1
    )

    completed_flight_mask = (
        ~cancelled_mask
        &
        ~diverted_mask
        &
        arrival_delay.notna()
    )

    # --------------------------------------------------------
    # On-time and delayed indicators
    # --------------------------------------------------------

    cleaned_data["On_Time_Flag"] = (
        completed_flight_mask
        &
        (arrival_delay < 15)
    )

    cleaned_data["Delayed_Flag"] = (
        completed_flight_mask
        &
        (arrival_delay >= 15)
    )

    # --------------------------------------------------------
    # Flight status
    # --------------------------------------------------------

    cleaned_data["Flight_Status"] = "On Time"

    cleaned_data.loc[
        cleaned_data["Delayed_Flag"],
        "Flight_Status"
    ] = "Delayed"

    cleaned_data.loc[
        diverted_mask,
        "Flight_Status"
    ] = "Diverted"

    cleaned_data.loc[
        cancelled_mask,
        "Flight_Status"
    ] = "Cancelled"

    # --------------------------------------------------------
    # Delay category
    # --------------------------------------------------------

    cleaned_data["Delay_Category"] = "On Time"

    cleaned_data.loc[
        completed_flight_mask
        &
        (arrival_delay < 0),
        "Delay_Category"
    ] = "Early"

    cleaned_data.loc[
        completed_flight_mask
        &
        (arrival_delay >= 15),
        "Delay_Category"
    ] = "Delayed"

    cleaned_data.loc[
        diverted_mask,
        "Delay_Category"
    ] = "Diverted"

    cleaned_data.loc[
        cancelled_mask,
        "Delay_Category"
    ] = "Cancelled"

    # --------------------------------------------------------
    # Delay severity
    # --------------------------------------------------------

    cleaned_data["Delay_Severity"] = "On Time"

    cleaned_data.loc[
        completed_flight_mask
        &
        (arrival_delay < 0),
        "Delay_Severity"
    ] = "Early"

    cleaned_data.loc[
        completed_flight_mask
        &
        (arrival_delay >= 15)
        &
        (arrival_delay < 60),
        "Delay_Severity"
    ] = "Moderate Delay"

    cleaned_data.loc[
        completed_flight_mask
        &
        (arrival_delay >= 60)
        &
        (arrival_delay < 180),
        "Delay_Severity"
    ] = "Severe Delay"

    cleaned_data.loc[
        completed_flight_mask
        &
        (arrival_delay >= 180),
        "Delay_Severity"
    ] = "Extreme Delay"

    cleaned_data.loc[
        diverted_mask,
        "Delay_Severity"
    ] = "Not Applicable - Diverted"

    cleaned_data.loc[
        cancelled_mask,
        "Delay_Severity"
    ] = "Not Applicable - Cancelled"

    # --------------------------------------------------------
    # Departure time category
    # --------------------------------------------------------

    def classify_departure_time(value: object) -> str:
        if pd.isna(value):
            return "Unknown"

        try:
            numeric_value = int(float(value))
        except (TypeError, ValueError):
            return "Unknown"

        departure_hour = numeric_value // 100

        if 5 <= departure_hour < 12:
            return "Morning"

        if 12 <= departure_hour < 17:
            return "Afternoon"

        if 17 <= departure_hour < 21:
            return "Evening"

        return "Night"

    cleaned_data["Departure_Time_Category"] = (
        cleaned_data["Scheduled_Departure"]
        .apply(classify_departure_time)
    )

    # --------------------------------------------------------
    # Weekend flag
    # --------------------------------------------------------

    cleaned_data["Weekend_Flag"] = (
        cleaned_data["Day_of_Week"]
        .isin([6, 7])
    )

    # --------------------------------------------------------
    # Season
    # --------------------------------------------------------

    season_map = {
        12: "Winter",
        1: "Winter",
        2: "Winter",
        3: "Spring",
        4: "Spring",
        5: "Spring",
        6: "Summer",
        7: "Summer",
        8: "Summer",
        9: "Fall",
        10: "Fall",
        11: "Fall"
    }

    cleaned_data["Season"] = (
        cleaned_data["Month"]
        .map(season_map)
        .fillna("Unknown")
    )

    # --------------------------------------------------------
    # Distance category
    # --------------------------------------------------------

    distance_values = pd.to_numeric(
        cleaned_data["Distance_Miles"],
        errors="coerce"
    )

    cleaned_data["Distance_Category"] = "Unknown"

    cleaned_data.loc[
        distance_values < 500,
        "Distance_Category"
    ] = "Short Haul"

    cleaned_data.loc[
        (distance_values >= 500)
        &
        (distance_values < 1500),
        "Distance_Category"
    ] = "Medium Haul"

    cleaned_data.loc[
        distance_values >= 1500,
        "Distance_Category"
    ] = "Long Haul"

    # --------------------------------------------------------
    # Total delay minutes
    # --------------------------------------------------------

    cleaned_data["Total_Delay_Minutes"] = (
        arrival_delay
        .clip(lower=0)
        .fillna(0)
    )

    # --------------------------------------------------------
    # Route performance and risk
    # --------------------------------------------------------

    route_analysis_mask = (
        cleaned_data["Route_Valid"]
        &
        completed_flight_mask
    )

    route_metrics = (
        cleaned_data.loc[
            route_analysis_mask
        ]
        .groupby("Route")
        .agg(
            Route_Flight_Count=(
                "Flight_ID",
                "size"
            ),
            Route_Average_Arrival_Delay=(
                "Arrival_Delay_Minutes",
                "mean"
            ),
            Route_Delayed_Flights=(
                "Delayed_Flag",
                "sum"
            )
        )
    )

    route_metrics["Route_Delay_Rate"] = (
        route_metrics["Route_Delayed_Flights"]
        /
        route_metrics["Route_Flight_Count"]
    )

    cleaned_data["Route_Delay_Rate"] = (
        cleaned_data["Route"]
        .map(route_metrics["Route_Delay_Rate"])
    )

    cleaned_data["Route_Average_Arrival_Delay"] = (
        cleaned_data["Route"]
        .map(
            route_metrics[
                "Route_Average_Arrival_Delay"
            ]
        )
    )

    def classify_route_risk(row: pd.Series) -> str:
        if not row["Route_Valid"]:
            return "Review Invalid Route"

        route_delay_rate = row["Route_Delay_Rate"]
        average_route_delay = (
            row["Route_Average_Arrival_Delay"]
        )

        if (
            pd.isna(route_delay_rate)
            or
            pd.isna(average_route_delay)
        ):
            return "Not Rated"

        if (
            route_delay_rate >= 0.75
            or
            average_route_delay >= 40
        ):
            return "High Risk"

        if (
            route_delay_rate >= 0.55
            or
            average_route_delay >= 25
        ):
            return "Moderate Risk"

        return "Low Risk"

    cleaned_data["Route_Risk_Category"] = (
        cleaned_data.apply(
            classify_route_risk,
            axis=1
        )
    )

    print("\nRoute Delay Rate Distribution:")
    print(cleaned_data["Route_Delay_Rate"].describe())

    print("\nRoute Average Arrival Delay Distribution:")
    print(cleaned_data["Route_Average_Arrival_Delay"].describe())

    print("\nCurrent Route Risk Categories:")
    print(cleaned_data["Route_Risk_Category"].value_counts(dropna=False))

    # --------------------------------------------------------
    # Display analytical-column summary
    # --------------------------------------------------------

    print("\nANALYTICAL COLUMN CREATION")
    print("-" * 70)

    print(
        f"On-time flights: "
        f"{cleaned_data['On_Time_Flag'].sum():,}"
    )

    print(
        f"Delayed flights: "
        f"{cleaned_data['Delayed_Flag'].sum():,}"
    )

    print(
        f"Cancelled flights: "
        f"{cancelled_mask.sum():,}"
    )

    print(
        f"Diverted flights: "
        f"{diverted_mask.sum():,}"
    )

    print("\nFLIGHT STATUS COUNTS")
    print("-" * 70)

    print(
        cleaned_data["Flight_Status"]
        .value_counts()
        .to_string()
    )

    print("\nROUTE RISK COUNTS")
    print("-" * 70)

    print(
        cleaned_data["Route_Risk_Category"]
        .value_counts()
        .to_string()
    )

    return cleaned_data

# ============================================================
# EXPORT CLEANED DATASET AND CLEANING SUMMARY
# ============================================================

def export_cleaned_outputs(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Export cleaned CSV, Excel workbook, and cleaning summary."""

    output_folder.mkdir(
        parents=True,
        exist_ok=True
    )

    csv_output_path = (
        output_folder
        /
        "Airline_Delay_and_Route_Performance_Cleaned.csv"
    )

    excel_output_path = (
        output_folder
        /
        "Airline_Delay_and_Route_Performance_Cleaned.xlsx"
    )

    summary_output_path = (
        output_folder
        /
        "Airline_Data_Cleaning_Summary.txt"
    )

    # --------------------------------------------------------
    # Export cleaned CSV
    # --------------------------------------------------------

    flight_data.to_csv(
        csv_output_path,
        index=False,
        encoding="utf-8-sig"
    )

    # --------------------------------------------------------
    # Export cleaned Excel workbook
    # --------------------------------------------------------

    with pd.ExcelWriter(
        excel_output_path,
        engine="openpyxl"
    ) as writer:

        flight_data.to_excel(
            writer,
            sheet_name="Cleaned_Flights",
            index=False
        )

        workbook = writer.book
        worksheet = writer.sheets["Cleaned_Flights"]

        worksheet.freeze_panes = "A2"
        worksheet.auto_filter.ref = (
            worksheet.dimensions
        )

        for column_cells in worksheet.columns:
            column_letter = (
                column_cells[0].column_letter
            )

            maximum_length = 0

            for cell in column_cells:
                cell_value = cell.value

                if cell_value is None:
                    continue

                maximum_length = max(
                    maximum_length,
                    len(str(cell_value))
                )

            adjusted_width = min(
                maximum_length + 2,
                35
            )

            worksheet.column_dimensions[
                column_letter
            ].width = adjusted_width

    # --------------------------------------------------------
    # Calculate summary values
    # --------------------------------------------------------

    total_rows = flight_data.shape[0]
    total_columns = flight_data.shape[1]

    duplicate_count = (
        flight_data
        .duplicated()
        .sum()
    )

    missing_value_count = (
        flight_data
        .isna()
        .sum()
        .sum()
    )

    invalid_origin_count = (
        ~flight_data["Origin_Airport_Valid"]
    ).sum()

    invalid_destination_count = (
        ~flight_data["Destination_Airport_Valid"]
    ).sum()

    invalid_route_count = (
        ~flight_data["Route_Valid"]
    ).sum()

    invalid_cancellation_count = (
        ~flight_data["Cancellation_Code_Valid"]
    ).sum()

    delay_outlier_count = (
        flight_data["Delay_Outlier_Flag"]
        .sum()
    )

    cancelled_flight_count = (
        flight_data["Cancelled"]
        .sum()
    )

    diverted_flight_count = (
        flight_data["Diverted"]
        .sum()
    )

    on_time_flight_count = (
        flight_data["On_Time_Flag"]
        .sum()
    )

    delayed_flight_count = (
        flight_data["Delayed_Flag"]
        .sum()
    )

    export_timestamp = (
        pd.Timestamp.now()
        .strftime("%Y-%m-%d %H:%M:%S")
    )

    # --------------------------------------------------------
    # Build summary text
    # --------------------------------------------------------

    summary_lines = [
        "=" * 70,
        "AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM",
        "DATA CLEANING SUMMARY",
        "=" * 70,
        "",
        f"Export timestamp: {export_timestamp}",
        "",
        "FINAL DATASET SIZE",
        "-" * 70,
        f"Rows: {total_rows:,}",
        f"Columns: {total_columns:,}",
        f"Exact duplicate records remaining: {duplicate_count:,}",
        f"Total missing values remaining: {missing_value_count:,}",
        "",
        "DATA QUALITY VALIDATION",
        "-" * 70,
        (
            "Invalid origin-airport records: "
            f"{invalid_origin_count:,}"
        ),
        (
            "Invalid destination-airport records: "
            f"{invalid_destination_count:,}"
        ),
        (
            "Invalid route records: "
            f"{invalid_route_count:,}"
        ),
        (
            "Invalid cancellation-code records: "
            f"{invalid_cancellation_count:,}"
        ),
        (
            "Delay-outlier records flagged: "
            f"{delay_outlier_count:,}"
        ),
        "",
        "FLIGHT PERFORMANCE SUMMARY",
        "-" * 70,
        f"On-time flights: {on_time_flight_count:,}",
        f"Delayed flights: {delayed_flight_count:,}",
        f"Cancelled flights: {cancelled_flight_count:,}",
        f"Diverted flights: {diverted_flight_count:,}",
        "",
        "FLIGHT STATUS COUNTS",
        "-" * 70,
        (
            flight_data["Flight_Status"]
            .value_counts()
            .to_string()
        ),
        "",
        "DELAY SEVERITY COUNTS",
        "-" * 70,
        (
            flight_data["Delay_Severity"]
            .value_counts()
            .to_string()
        ),
        "",
        "ROUTE RISK COUNTS",
        "-" * 70,
        (
            flight_data["Route_Risk_Category"]
            .value_counts()
            .to_string()
        ),
        "",
        "DISTANCE CATEGORY COUNTS",
        "-" * 70,
        (
            flight_data["Distance_Category"]
            .value_counts()
            .to_string()
        ),
        "",
        "EXPORTED FILES",
        "-" * 70,
        csv_output_path.name,
        excel_output_path.name,
        summary_output_path.name,
        "",
        "CLEANING ACTIONS COMPLETED",
        "-" * 70,
        "1. Loaded and profiled the raw flight dataset.",
        "2. Removed exact duplicate records.",
        "3. Standardized airline names.",
        "4. Filled recoverable location and source values.",
        "5. Validated airport codes and routes.",
        "6. Standardized cancellation codes and reasons.",
        "7. Flagged suspicious delay outliers.",
        "8. Converted HHMM fields into readable time values.",
        "9. Added analytical columns for SQL and Power BI.",
        "10. Exported the cleaned dataset and summary.",
        "",
        "IMPORTANT DATA-QUALITY NOTES",
        "-" * 70,
        (
            "Invalid or suspicious records were flagged rather "
            "than automatically deleted."
        ),
        (
            "Blank actual times are expected for certain "
            "cancelled flights."
        ),
        (
            "Blank cancellation codes are expected for "
            "non-cancelled flights."
        ),
        (
            "Negative delay values may represent flights that "
            "departed or arrived early."
        ),
        "",
        "=" * 70,
        "PHASE 3 DATA CLEANING COMPLETED",
        "=" * 70
    ]

    summary_text = "\n".join(
        str(line)
        for line in summary_lines
    )

    summary_output_path.write_text(
        summary_text,
        encoding="utf-8"
    )

    # --------------------------------------------------------
    # Display export results
    # --------------------------------------------------------

    print("\nCLEANED DATA EXPORT")
    print("-" * 70)

    print(
        f"CSV exported successfully:\n"
        f"{csv_output_path}"
    )

    print()

    print(
        f"Excel workbook exported successfully:\n"
        f"{excel_output_path}"
    )

    print()

    print(
        f"Cleaning summary exported successfully:\n"
        f"{summary_output_path}"
    )
           
# ============================================================
# MAIN PROGRAM
# ============================================================

def main() -> None:
    """Run the initial raw-data inspection."""

    try:
        flight_data = load_raw_flight_data(RAW_FILE) 

        display_initial_profile(flight_data)

        cleaned_data = remove_duplicate_records(
            flight_data
        )

        cleaned_data = standardize_airline_names(
            cleaned_data
        )

        cleaned_data = handle_missing_location_and_source_values(
            cleaned_data
        )

        cleaned_data = validate_airport_codes(
            cleaned_data
        )

        cleaned_data = standardize_cancellation_codes(
            cleaned_data
        )

        cleaned_data = flag_delay_outliers(
            cleaned_data
        )

        cleaned_data = convert_hhmm_fields(
            cleaned_data
        )

        cleaned_data = add_analytical_columns(
            cleaned_data
        )

        export_cleaned_outputs(
            cleaned_data,
            CLEANED_DATA_FOLDER
        )

        print("\nCLEANED DATASET SIZE")
        print("-" * 70)
        print(f"Rows: {cleaned_data.shape[0]:,}")
        print(f"Columns: {cleaned_data.shape[1]:,}")

        print("\n" + "=" * 70)
        print("PHASE 3, PART 10 COMPLETED SUCCESSFULLY")
        print("=" * 70)

    except FileNotFoundError as error: 
        print("\nFILE ERROR")
        print("-" * 70)
        print(error)

    except ValueError as error:
        print("\nWORKSHEET ERROR")
        print("-" * 70)
        print(
            "The Raw_Flights worksheet could not be loaded."
        )
        print(error)

    except Exception as error:
        print("\nUNEXPECTED ERROR")
        print("-" * 70)
        print(type(error).__name__)
        print(error)


if __name__ == "__main__":
    main()  


























































