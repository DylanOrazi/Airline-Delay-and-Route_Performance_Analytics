# ============================================================
# AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM
# PYTHON EXPLORATORY DATA ANALYSIS
# ============================================================

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


# ============================================================
# PROJECT PATHS
# ============================================================

SCRIPT_FOLDER = Path(__file__).resolve().parent

PROJECT_FOLDER = SCRIPT_FOLDER.parent

CLEANED_DATA_FOLDER = (
    PROJECT_FOLDER
    /
    "Data"
    /
    "Cleaned"
)

CLEANED_DATA_FILE = (
    CLEANED_DATA_FOLDER
    /
    "Airline_Delay_and_Route_Performance_Cleaned.csv"
)

PYTHON_CHARTS_FOLDER = (
    PROJECT_FOLDER
    /
    "Exports"
    /
    "Python Charts"
)

PYTHON_ANALYSIS_FOLDER = (
    PROJECT_FOLDER
    /
    "Exports"
    /
    "Python Analysis"
)


# ============================================================
# LOAD CLEANED DATASET
# ============================================================

def load_cleaned_dataset(
    file_path: Path
) -> pd.DataFrame:
    """Load the cleaned airline dataset from CSV."""

    print("=" * 70)
    print("AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM")
    print("PYTHON EXPLORATORY DATA ANALYSIS")
    print("=" * 70)

    print("\nCLEANED DATASET LOCATION")
    print("-" * 70)
    print(file_path)

    if not file_path.exists():
        raise FileNotFoundError(
            "The cleaned dataset coud not be found:\n"
            f"{file_path}"
        )

    flight_data = pd.read_csv(
        file_path,
        low_memory=False
    )

    print("\nDATASET LOADED SUCCESSFULLY")
    print("-" * 70)
    print(f"Rows loaded: {flight_data.shape[0]:,}")
    print(f"Columns loaded: {flight_data.shape[1]:,}")

    return flight_data


# ============================================================
# PREPARE DATA TYPES FOR ANALYSIS
# ============================================================


def prepare_analysis_data_types(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Prepare important columns for exploratory analysis."""

    analysis_data = flight_data.copy()

    analysis_data["Flight_Date"] = pd.to_datetime(
        analysis_data["Flight_Date"],
        errors="coerce"
    )

    numeric_columns = [
        "Year",
        "Quarter",
        "Month",
        "Day_of_Month",
        "Day_of_Week",
        "Departure_Delay_Minutes",
        "Arrival_Delay_Minutes",
        "Distance_Miles",
        "Cancelled",
        "Diverted",
        "Total_Delay_Minutes",
        "Route_Delay_Rate",
        "Route_Average_Arrival_Delay"
    ]

    for column_name in numeric_columns:
        if column_name in analysis_data.columns:
            analysis_data[column_name] = pd.to_numeric(
                analysis_data[column_name],
                errors="coerce"
            )

    boolean_columns = [
        "Origin_Airport_Valid",
        "Destination_Airport_Valid",
        "Route_Valid",
        "Cancellation_Code_Valid",
        "Departure_Delay_Outlier",
        "Arrival_Delay_Outlier",
        "Delay_Outlier_Flag",
        "On_Time_Flag",
        "Delayed_Flag",
        "Weekend_Flag"
    ]

    boolean_value_map = {
        True: True,
        False: False,
        1: True,
        0: False,
        "True": True,
        "False": False,
        "true": True,
        "false": False,
        "1": True,
        "0": False
    }

    for column_name in boolean_columns:
        if column_name in analysis_data.columns:
            analysis_data[column_name] = (
                analysis_data[column_name]
                .map(boolean_value_map)
                .astype("boolean")
            )

    return analysis_data


# ============================================================
# VALIDATE REQUIRED COLUMNS
# ============================================================

def validate_required_columns(
    flight_data: pd.DataFrame
) -> None:
    """Confirm that essential analytical columns are available."""

    required_columns = [
        "Flight_ID",
        "Flight_Date",
        "Airline_Code",
        "Airline_Name",
        "Origin_Airport",
        "Destination_Airport",
        "Route",
        "Departure_Delay_Minutes",
        "Arrival_Delay_Minutes",
        "Distance_Miles",
        "Flight_Status",
        "Delay_Severity",
        "Departure_Time_Category",
        "Season",
        "Distance_Category",
        "Route_Risk_Category",
        "On_Time_Flag",
        "Delayed_Flag"
    ]

    missing_required_columns = [
        column_name
        for column_name in required_columns
        if column_name not in flight_data.columns
    ]

    print("\nREQUIRED COLUMN VALIDATION")
    print("-" * 70)

    if missing_required_columns:
        print("Missing required columns:")

        for column_name in missing_required_columns:
            print(f"- {column_name}")

        raise ValueError(
            "The cleaned dataset is missing one or more "
            "required analytical columns."
        )

    print(
        f"Required analytical columns found: "
        f"{len(required_columns):,}"
    )

    print("Missing required analytical columns: 0")


# ============================================================
# DISPLAY DATASET PROFILE
# ============================================================

def display_dataset_profile(
    flight_data: pd.DataFrame
) -> None:
    """Display a complete profile of the cleaned dataset."""

    print("\nFINAL DATASET DIMENSION")
    print("-" * 70)
    print(f"Rows: {flight_data.shape[0]:,}")
    print(f"Columns: {flight_data.shape[1]:,}")

    print("\nFLIGHT DATE RANGE")
    print("-" * 70)

    valid_flight_dates = (
        flight_data["Flight_Date"]
        .dropna()

    )

    if not valid_flight_dates.empty:
        print(
            "Earliest flight date: "
            f"{valid_flight_dates.min().date()}"
        )

        print(
            "Latest flight date: "
            f"{valid_flight_dates.max().date()}"
        )

        print(
            "Distinct flight dates: "
            f"{valid_flight_dates.nunique():,}"
        )
    else:
        print("No valid flight dates were detected.")

    print("\nUNIQUE ANALYTICAL ENTITIES")
    print("-" * 70)

    print(
        "Unique flight IDs: "
        f"{flight_data['Flight_ID'].nunique():,}"
    )

    print(
        "Unique airlines: "
        f"{flight_data['Airline_Code'].nunique():,}"
    )

    print(
        "Unique origin airports: "
        f"{flight_data['Origin_Airport'].nunique():,}"
    )

    print(
        "Unique destination airports: "
        f"{flight_data['Destination_Airport'].nunique():,}"
    )

    print(
        "Unique routes: "
        f"{flight_data['Route'].nunique():,}"
    )

    repeated_flight_id_records = (
        flight_data.shape[0]
        -
        flight_data["Flight_ID"].nunique()
    )

    print(
        "Repeated Flight_ID records: "
        f"{repeated_flight_id_records:,}"
    )


# ============================================================
# DISPLAY DATA TYPE SUMMARY
# ============================================================

def display_data_type_summary(
    flight_data: pd.DataFrame
) -> None:
    """Display the number of columns by pandas data type."""

    data_type_summary = (
        flight_data.dtypes
        .astype(str)
        .value_counts()
        .rename_axis("Data_Type")
        .reset_index(name="Column_Count")
    )

    print("\nDATA TYPE SUMMARY")
    print("-" * 70)
    print(
        data_type_summary.to_string(
            index=False
        )
    )


# ============================================================
# DISPLAY MISSING VALUE SUMMARY
# ============================================================

def display_missing_value_summary(
    flight_data: pd.DataFrame
) -> None:
    """Display columns containing missing values."""

    missing_value_summary = pd.DataFrame(
        {
            "Missing_Count": (
                flight_data.isna().sum()
            ),
            "Missing_Percent": (
                flight_data.isna().mean() * 100
            )
        }
    )

    missing_value_summary = (
        missing_value_summary[
            missing_value_summary["Missing_Count"] > 0

        ]
        .sort_values(
            by="Missing_Count",
            ascending=False
        )
    )

    print("\nMISSING VALUE SUMMARY")
    print("-" * 70)

    if missing_value_summary.empty:
        print("No missing value were detected.")
        return

    missing_value_summary["Missing_Percent"] = (
        missing_value_summary["Missing_Percent"]
        .round(2)
    )

    print(
        missing_value_summary.to_string()
    )

    print(
        "\nTotal missing values: "
        f"{flight_data.isna().sum().sum():,}"
    )


# ============================================================
# DISPLAY NUMERIC SUMMARY
# ============================================================

def display_numeric_summary(
    flight_data: pd.DataFrame
) -> None:
    """Display descriptive statistics for key numeric columns."""

    numeric_profile_columns = [
        "Departure_Delay_Minutes",
        "Arrival_Delay_Minutes",
        "Total_Delay_Minutes",
        "Distance_Miles",
        "Route_Delay_Rate",
        "Route_Average_Arrival_Delay"
    ]

    available_numeric_columns = [
        column_name
        for column_name in numeric_profile_columns
        if column_name in flight_data.columns
    ]

    numeric_summary = (
        flight_data[available_numeric_columns]
        .describe()
        .transpose()
        .round(2)
    )

    print("\nKEY NUMERIC FIELD SUMMARY")
    print("-" * 70)
    print(numeric_summary.to_string())


# ============================================================
# DISPLAY CATEGORY SUMMARY
# ============================================================

def display_category_summary(
    flight_data: pd.DataFrame
) -> None:
    """Display counts for important analytical categories."""

    category_columns = [
        "Flight_Status",
        "Delay_Severity",
        "Departure_Time_Category",
        "Season",
        "Distance_Category",
        "Route_Risk_Category",
    ]

    for column_name in category_columns:
        print(f"\n{column_name.upper()} COUNTS")
        print("-" * 70)

        print(
            flight_data[column_name]
            .value_counts(
                dropna=False
            )
            .to_string()

        )


# ============================================================
# PREPARE PERFORMANCE METRICS
# ============================================================

def prepare_performance_metrics(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Create temporary numeric fields for grouped analysis."""

    performance_data = flight_data.copy()

    performance_data["_Flight_Record"] = 1

    performance_data["_On_Time_Record"] = (
        performance_data["Flight_Status"]
        .eq("On Time")
        .astype(int)
    )

    performance_data["_Delayed_Record"] = (
        performance_data["Flight_Status"]
        .eq("Delayed")
        .astype(int)
    )

    performance_data["_Cancelled_Record"] = (
        performance_data["Flight_Status"]
        .eq("Cancelled")
        .astype(int)
    )

    performance_data["_Diverted_Record"] = (
        performance_data["Flight_Status"]
        .eq("Diverted")
        .astype(int)
    )

    completed_flight_mask = (
        ~performance_data["Flight_Status"].isin(
            [
                "Cancelled",
                "Diverted"
            ]
        )
    )

    performance_data[
        "_Completed_Departure_Delay"
    ] = performance_data[
        "Departure_Delay_Minutes"
    ].where(completed_flight_mask)

    performance_data[
        "_Completed_Arrival_Delay"
    ] = performance_data[
        "Arrival_Delay_Minutes"
    ].where(completed_flight_mask)

    return performance_data


# ============================================================
# BUILD GROUPED PERFORMANCE SUMMARY
# ============================================================

def build_grouped_performance_summary(
    flight_data: pd.DataFrame,
    group_columns: list[str]
) -> pd.DataFrame:
    """Build a standardized flight-performance summary."""

    performance_summary = (
        flight_data
        .groupby(
            group_columns,
            dropna=False
        )
        .agg(
            Total_Flights=(
                "_Flight_Record",
                "sum"
            ),
            On_Time_Flights=(
                "_On_Time_Record",
                "sum"
            ),
            Delayed_Flights=(
                "_Delayed_Record",
                "sum"
            ),
            Cancelled_Flights=(
                "_Cancelled_Record",
                "sum"
            ),
            Diverted_Flights=(
                "_Diverted_Record",
                "sum"
            ),
            Average_Departure_Delay=(
                "_Completed_Departure_Delay",
                "mean"
            ),
            Median_Departure_Delay=(
                "_Completed_Departure_Delay",
                "median"
            ),
            Average_Arrival_Delay=(
                "_Completed_Arrival_Delay",
                "mean"
            ),
            Median_Arrival_Delay=(
                "_Completed_Arrival_Delay",
                "median"
            ),
            Average_Distance_Miles=(
                "Distance_Miles",
                "mean"
            )
        )
        .reset_index()
    )

    performance_summary[
        "On_Time_Rate_Percent"
    ] = (
        100
        *
        performance_summary["On_Time_Flights"]
        /
        performance_summary["Total_Flights"]
    )

    performance_summary[
        "Delay_Rate_Percent"
    ] = (
        100
        *
        performance_summary["Delayed_Flights"]
        /
        performance_summary["Total_Flights"]
    )

    performance_summary[
        "Cancellation_Rate_Percent"
    ] = (
        100
        *
        performance_summary["Cancelled_Flights"]
        /
        performance_summary["Total_Flights"]
    )

    deciaml_columns = [
        "Average_Departure_Delay",
        "Median_Departure_Delay",
        "Average_Arrival_Delay",
        "Median_Arrival_Delay",
        "Average_Distance_Miles",
        "On_Time_Rate_Percent",
        "Delay_Rate_Percent",
        "Cancellation_Rate_Percent"
    ]

    performance_summary[deciaml_columns] = (
        performance_summary[deciaml_columns]
        .round(2)
    )

    return performance_summary


# ============================================================
# DISPLAY OVERALL PERFORMANCE SUMMARY
# ============================================================

def display_overall_performance_summary(
    flight_data: pd.DataFrame
) -> None:
    """Display overall flight-performance statistics."""

    total_flights = len(flight_data)

    on_time_flights = (
        flight_data["_On_Time_Record"]
        .sum()
    )

    delayed_flights = (
        flight_data["_Delayed_Record"]
        .sum()
    )

    cancelled_flights = (
        flight_data["_Cancelled_Record"]
        .sum()
    )

    diverted_flights = (
        flight_data["_Diverted_Record"]
        .sum()
    )

    on_time_rate = (
        100
        *
        on_time_flights
        /
        total_flights
    )

    delay_rate = (
        100
        *
        delayed_flights
        /
        total_flights
    )

    cancellation_rate = (
        100
        *
        cancelled_flights
        /
        total_flights
    )

    average_departure_delay = (
        flight_data[
            "_Completed_Departure_Delay"
        ]
        .mean()
    )

    median_departure_delay = (
        flight_data[
            "_Completed_Departure_Delay"
        ]
        .median()
    )

    average_arrival_delay = (
        flight_data[
            "_Completed_Arrival_Delay"
        ]
        .mean()
    )

    median_arrival_delay = (
        flight_data[
            "_Completed_Arrival_Delay"
        ]
        .median()
    )

    print("\nOVERALL FLIGHT PERFORMANCE")
    print("-" * 70)

    print(f"Total flights: {total_flights:,}")
    print(f"On_Time flights: {on_time_flights:,}")
    print(f"Delayed flights: {delayed_flights:,}")
    print(f"Cancelled flights: {cancelled_flights:,}")
    print(f"Diverted flights: {diverted_flights:,}")

    print(
        f"On_Time rate: "
        f"{on_time_rate:.2f}%"
    )

    print(
        f"Delay rate: "
        f"{delay_rate:.2f}%"
    )

    print(
        f"Cancellation rate: "
        f"{cancellation_rate:.2f}%"
    )

    print(
        f"Average departure delay: "
        f"{average_departure_delay:.2f} minutes"
    )

    print(
        f"Median departure delay: "
        f"{median_departure_delay:.2f} minutes"
    )

    print(
        f"Average arrival delay: "
        f"{average_arrival_delay:.2f} minutes"
    )

    print(
        f"Median arrival delay: "
        f"{median_arrival_delay:.2f} minutes"
    )


# ============================================================
# DISPLAY AIRLINE PERFORMANCE SUMMARY
# ============================================================

def display_airline_performance_summary(
    flight_data: pd.DataFrame
) -> None:
    """Compare operational performance by airline."""

    airline_summary = (
        build_grouped_performance_summary(
            flight_data,
            [
                "Airline_Code",
                "Airline_Name"
            ]
        )
    )

    airline_summary["Reliability_Rank"] = (
        airline_summary[
            "On_Time_Rate_Percent"
        ]
        .rank(
            method="min",
            ascending=False
        )
        .astype(int)
    )

    airline_summary = (
        airline_summary
        .sort_values(
            by=[
                "Reliability_Rank",
                "Average_Arrival_Delay"
            ],
            ascending=[
                True,
                True
            ]
        )
    )

    display_columns = [
        "Airline_Code",
        "Airline_Name",
        "Total_Flights",
        "On_Time_Rate_Percent",
        "Delay_Rate_Percent",
        "Cancellation_Rate_Percent",
        "Average_Arrival_Delay",
        "Reliability_Rank"
    ]

    print("\nAIRLINE PERFORMANCE SUMMARY")
    print("-" * 70)

    print(
        airline_summary[display_columns]
        .to_string(index=False)
    )


# ============================================================
# DISPLAY ORIGIN AIRPORT PERFORMANCE
# ============================================================

def display_origin_airport_performance(
    flight_data: pd.DataFrame
) -> None:
    """Compare performance across valid origin airports."""

    valid_origin_data = flight_data.loc[
        flight_data["Origin_Airport_Valid"]
        .fillna(False)
    ].copy()

    airport_summary = (
        build_grouped_performance_summary(
            valid_origin_data,
            [
                "Origin_Airport",
                "Origin_City",
                "Origin_State"
            ]
        )
    )

    airport_summary = (
        airport_summary.loc[
            airport_summary["Total_Flights"] >= 100
        ]
        .sort_values(
            by=[
                "Delay_Rate_Percent",
                "Average_Departure_Delay"
            ],
            ascending=[
                False,
                False
            ]
        )
    )

    display_columns = [
        "Origin_Airport",
        "Origin_City",
        "Origin_State",
        "Total_Flights",
        "On_Time_Rate_Percent",
        "Delay_Rate_Percent", 
        "Average_Departure_Delay",
        "Average_Arrival_Delay"
    ]

    print("\nORIGIN AIRPORT PERFORMANCE")
    print("-" * 70)

    print(
        airport_summary[display_columns]
        .to_string(index=False)
    )


# ============================================================
# DISPLAY MONTHLY PERFORMANCE
# ============================================================
    
def display_monthly_performance(
    flight_data: pd.DataFrame
) -> None:
    """Display monthly flight-performance trends."""

    monthly_summary = (
        build_grouped_performance_summary(
            flight_data,
            [
                "Year",
                "Month"
            ]
        )
    )

    month_name_map = {
        1: "January",
        2: "February",
        3: "March",
        4: "April",
        5: "May",
        6: "June",
        7: "July",
        8: "August",
        9: "September",
        10: "October",
        11: "November",
        12: "December"
    }

    monthly_summary["Month_Name"] = (
        monthly_summary["Month"]
        .map(month_name_map)
        .fillna("Unknown")
    )

    monthly_summary = (
        monthly_summary
        .sort_values(
            by=[
                "Year",
                "Month"
            ]
        )
    )

    monthly_summary[
        "Three_Month_On_Time_Average"
    ] = (
        monthly_summary[
            "On_Time_Rate_Percent"
        ]
        .rolling(
            window=3,
            min_periods=1
        )
        .mean()
        .round(2)
    )

    monthly_summary[
        "Previous_Month_On_Time_Rate"
    ] = (
        monthly_summary[
            "On_Time_Rate_Percent"
        ]
        .shift(1)
    )

    monthly_summary[
        "On_Time_Rate_Change"
    ] = (
        monthly_summary[
            "On_Time_Rate_Percent"
        ]
        -
        monthly_summary[
            "Previous_Month_On_Time_Rate"
        ]
    ).round(2)

    display_columns = [
        "Year",
        "Month",
        "Month_Name",
        "Total_Flights",
        "On_Time_Rate_Percent",
        "Delay_Rate_Percent",
        "Average_Arrival_Delay",
        "Three_Month_On_Time_Average",
        "On_Time_Rate_Change"
    ]

    print("\nMONTHLY PERFORMANCE SUMMARY")
    print("-" * 70)

    print(
        monthly_summary[display_columns]
        .to_string(index=False)
    )


# ============================================================
# DISPLAY SEGMENT PERFORMANCE
# ============================================================

def display_segment_performance(
    flight_data: pd.DataFrame
) -> None:
    """Compare performance across major analytical segments."""

    segment_columns = [
        "Season",
        "Departure_Time_Category",
        "Distance_Category",
        "Route_Risk_Category"
    ]

    for column_name in segment_columns:
        segment_summary = (
            build_grouped_performance_summary(
                flight_data,
                [column_name]
            )
        )

        segment_summary = (
            segment_summary
            .sort_values(
                by="Delay_Rate_Percent",
                ascending=False
            )
        )

        display_columns = [
            column_name,
            "Total_Flights",
            "On_Time_Rate_Percent",
            "Delay_Rate_Percent",
            "Cancellation_Rate_Percent",
            "Average_Arrival_Delay"
        ]

        heading = (
            column_name
            .replace("_", " ")
            .upper()
        )

        print(f"\n{heading} PERFORMANCE")
        print("-" * 70)

        print(
            segment_summary[display_columns]
            .to_string(index=False)
        )


# ============================================================
# SAVE CHART
# ============================================================

def save_chart(
    figure: plt.Figure,
    output_folder: Path,
    file_name: str
) -> None:
    """Save a completed chart as a high_resolution PNG file."""

    output_folder.mkdir(
        parents=True,
        exist_ok=True
    )

    output_path = (
        output_folder
        /
        file_name
    )

    figure.tight_layout()

    figure.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close(figure)

    print(
        f"Chart exported successfully: "
        f"{output_path.name}"
    )


# ============================================================
# CREATE FLIGHT STATUS DISTRIBUTION CHART
# ============================================================

def create_flight_status_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Create a bar chart showing flight-status totals."""

    status_order = [
        "On Time",
        "Delayed",
        "Cancelled",
        "Diverted"
    ]

    status_counts = (
        flight_data["Flight_Status"]
        .value_counts()
        .reindex(
            status_order,
            fill_value=0
        )
    )

    figure, axis = plt.subplots(
        figsize=(10, 6)
    )

    bars = axis.bar(
        status_counts.index,
        status_counts.values
    )

    axis.set_title(
        "Flight Status Distribution",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "Flight Status",
        fontsize=11
    )

    axis.set_ylabel(
        "Number of Flights",
        fontsize=11
    )

    axis.grid(
        axis="y",
        alpha=0.25
    )

    axis.tick_params(
        axis="x",
        rotation=0
    )

    axis.bar_label(
        bars,
        labels=[
            f"{value:,}"
            for value in status_counts.values
        ],
        padding=4
    )

    maximum_value = (
        status_counts.max()
    )

    axis.set_ylim(
        0,
        maximum_value * 1.12
    )

    save_chart(
        figure,
        output_folder,
        "01_flight_status_distribution.png"
    )


# ============================================================
# CREATE AIRLINE ON-TIME RATE CHART
# ============================================================

def create_airline_on_time_rate_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Create a horizontal airline on-time-rate chart."""

    airline_summary = (
        build_grouped_performance_summary(
            flight_data,
            [
                "Airline_Code",
                "Airline_Name"
            ]
        )
    )

    airline_summary = (
        airline_summary
        .sort_values(
            by="On_Time_Rate_Percent",
            ascending=True
        )
    )

    figure, axis = plt.subplots(
        figsize=(11, 7)
    )

    bars = axis.barh(
        airline_summary["Airline_Name"],
        airline_summary[
            "On_Time_Rate_Percent"
        ]
    )

    axis.set_title(
        "Airline On_Time Performance",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "On_Time Rate (%)",
        fontsize=11
    )

    axis.set_ylabel(
        "Airline",
        fontsize=11
    )

    axis.grid(
        axis="x",
        alpha=0.25
    )

    axis.bar_label(
        bars,
        labels=[
            f"{value:.2f}%"
            for value in airline_summary[
                "On_Time_Rate_Percent"
            ]
        ],
        padding=4
    )

    maximum_rate = (
        airline_summary[
            "On_Time_Rate_Percent"
        ]
        .max()
    )

    axis.set_xlim(
        0,
        maximum_rate + 8
    )

    save_chart(
        figure,
        output_folder,
        "02_airline_on_time_rate.png"
    )


# ============================================================
# CREATE MONTHLY ON-TIME PERFORMANCE CHART
# ============================================================

def create_monthly_on_time_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Create a monthly on-time-rate trend chart."""

    monthly_summary = (
        build_grouped_performance_summary(
            flight_data,
            [
                "Year",
                "Month"
            ]
        )
    )

    monthly_summary["Year"] = (
        pd.to_numeric(
            monthly_summary["Year"],
            errors="coerce"
        )
    )

    monthly_summary["Month"] = (
        pd.to_numeric(
            monthly_summary["Month"],
            errors="coerce"
        )
    )

    monthly_summary = (
        monthly_summary
        .sort_values(
            by=[
                "Year",
                "Month"
            ]
        )
        .reset_index(drop=True)
    )

    month_abbreviation_map = {
        1: "Jan",
        2: "Feb",
        3: "Mar",
        4: "Apr",
        5: "May",
        6: "Jun",
        7: "Jul",
        8: "Aug",
        9: "Sep",
        10: "Oct",
        11: "Nov",
        12: "Dec"
    }

    monthly_summary["Month_Label"] = (
        monthly_summary["Month"]
        .map(month_abbreviation_map)
        .fillna("Unknown")
    )

    monthly_summary[
        "Three_Month_Moving_Average"
    ] = (
        monthly_summary[
            "On_Time_Rate_Percent"
        ]
        .rolling(
            window=3,
            min_periods=1
        )
        .mean()
    )

    figure, axis = plt.subplots(
        figsize=(12, 6)
    )

    axis.plot(
        monthly_summary["Month_Label"],
        monthly_summary[
            "On_Time_Rate_Percent"
        ],
        marker="o",
        linewidth=2,
        label="Monthly on-time rate"
    )

    axis.plot(
        monthly_summary["Month_Label"],
        monthly_summary[
            "Three_Month_Moving_Average"
        ],
        marker="s",
        linestyle="--",
        linewidth=2,
        label="Three-month moving average"
    )

    axis.set_title(
        "Monthly On-Time Performance Trend",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "Month",
        fontsize=11
    )

    axis.set_ylabel(
        "On-Time Rate (%)",
        fontsize=11
    )

    axis.grid(
        alpha=0.25
    )

    axis.legend()

    for row_number, row in (
        monthly_summary.iterrows()
    ):
        axis.annotate(
            f"{row['On_Time_Rate_Percent']:.1f}%",
            (
                row_number,
                row["On_Time_Rate_Percent"]
            ),
            textcoords="offset points",
            xytext=(0, 8),
            ha="center",
            fontsize=8
        )

    save_chart(
        figure,
        output_folder,
        "03_monthly_on_time_performance.png"
    )


# ============================================================
# CREATE DELAY SEVERITY DISTRIBUTION CHART
# ============================================================

def create_delay_severity_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Create a bar chart showing delay-severity totals."""

    severity_order = [
        "Early",
        "On Time",
        "Moderate Delay",
        "Severe Delay",
        "Extreme Delay",
        "Not Applicable - Diverted",
        "Not Applicable - Cancelled"
    ]

    severity_counts = (
        flight_data["Delay_Severity"]
        .value_counts()
        .reindex(
            severity_order,
            fill_value=0
        )
    )

    figure, axis = plt.subplots(
        figsize=(12, 7)
    )

    bars = axis.bar(
        severity_counts.index,
        severity_counts.values
    )

    axis.set_title(
        "Delay Severity Distribution",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "Delay_Severity",
        fontsize=11
    )

    axis.set_ylabel(
        "Number of Flights",
        fontsize=11
    )

    axis.grid(
        axis="y",
        alpha=0.25
    )

    axis.tick_params(
        axis="x",
        rotation=30
    )

    for label in axis.get_xticklabels():
        label.set_horizontalalignment(
            "right"
        )

    axis.bar_label(
        bars,
        labels=[
            f"{value:,}"
            for value in severity_counts.values
        ],
        padding=4,
        fontsize=9
    )

    maximum_value = (
        severity_counts.max()
    )

    axis.set_ylim(
        0,
        maximum_value * 1.12
    )

    save_chart(
        figure,
        output_folder,
        "04_delay_severity_distribution.png"
    )
        

# ============================================================
# CREATE ALL CORE CHARTS
# ============================================================

def create_core_charts(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Create all Phase 5, Part 3 charts."""

    print("\nCORE PYTHON CHART CREATION")
    print("-" * 70)

    create_flight_status_chart(
        flight_data,
        output_folder
    )

    create_airline_on_time_rate_chart(
        flight_data,
        output_folder
    )

    create_monthly_on_time_chart(
        flight_data,
        output_folder
    )

    create_delay_severity_chart(
        flight_data,
        output_folder
    )


# ============================================================
# CREATE AIRLINE RELIABILITY COMPARISON CHART
# ============================================================

def create_airline_reliability_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Compare airline on-time rates and arrival delays."""

    airline_summary = (
        build_grouped_performance_summary(
            flight_data,
            [
                "Airline_Code",
                "Airline_Name"
            ]
        )
    )

    figure, axis = plt.subplots(
        figsize=(11, 7)
    )

    axis.scatter(
        airline_summary[
            "On_Time_Rate_Percent"
        ],
        airline_summary[
            "Average_Arrival_Delay"
        ],
        s=100,
        alpha=0.75
    )

    for _, row in airline_summary.iterrows():
        axis.annotate(
            row["Airline_Code"],
            (
                row["On_Time_Rate_Percent"],
                row["Average_Arrival_Delay"]
            ),
            textcoords="offset points",
            xytext=(6, 6),
            fontsize=9
        )

    overall_on_time_rate = (
        100
        *
        flight_data["_On_Time_Record"].sum()
        /
        len(flight_data)
    )

    overall_arrival_delay = (
        flight_data[
            "_Completed_Arrival_Delay"
        ]
        .mean()
    )

    axis.axvline(
        overall_on_time_rate,
        linestyle="--",
        linewidth=1.5,
        label=(
            "Overall on-time rate: "
            f"{overall_on_time_rate:.2f}%"
        )
    )

    axis.axhline(
        overall_arrival_delay,
        linestyle="--",
        linewidth=1.5,
        label=(
            "Overall arrival delay: "
            f"{overall_arrival_delay:.2f} min"
        )
    )

    axis.set_title(
        "Airline Reliability Comparison",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "On-Time Rate (%)",
        fontsize=11
    )

    axis.set_ylabel(
        "Average Arrival Delay (Minutes)",
        fontsize=11
    )

    axis.grid(
        alpha=0.25
    )

    axis.legend(
        loc="best"
    )

    save_chart(
        figure,
        output_folder,
        "05_airline_reliability_comparison.png"
    )


# ============================================================
# CREATE DEPARTURE TIME PERFORMANCE CHART
# ============================================================

def create_departure_time_performance_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Compare on-time and delay rates by departure period."""

    departure_summary = (
        build_grouped_performance_summary(
            flight_data,
            ["Departure_Time_Category"]
        )
    )

    departure_order = [
        "Morning",
        "Afternoon",
        "Evening",
        "Night",
        "Unknown"
    ]

    departure_summary[
        "Departure_Time_Category"
    ] = pd.Categorical(
        departure_summary[
            "Departure_Time_Category"
        ],
        categories=departure_order,
        ordered=True
    )

    departure_summary = (
        departure_summary
        .sort_values(
            by="Departure_Time_Category"
        )
        .dropna(
            subset=[
                "Departure_Time_Category"
            ]
        )
        .reset_index(drop=True)
    )

    positions = list(
        range(len(departure_summary))
    )

    bar_width = 0.36

    left_positions = [
        position - bar_width / 2
        for position in positions
    ]

    right_positions = [
        position + bar_width / 2
        for position in positions
    ]

    figure, axis = plt.subplots(
        figsize=(11, 7)
    )

    on_time_bars = axis.bar(
        left_positions,
        departure_summary[
            "On_Time_Rate_Percent"
        ],
        width=bar_width,
        label="On-time rate"
    )

    delay_bars = axis.bar(
        right_positions,
        departure_summary[
            "Delay_Rate_Percent"
        ],
        width=bar_width,
        label="Delay rate"
    )

    axis.set_title(
        "Performance by Scheduled Departure Period",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "Departure Time Category",
        fontsize=11
    )

    axis.set_ylabel(
        "Rate (%)",
        fontsize=11
    )

    axis.set_xticks(
        positions
    )

    axis.set_xticklabels(
        departure_summary[
            "Departure_Time_Category"
        ]
        .astype(str)
    )

    axis.grid(
        axis="y",
        alpha=0.25
    )

    axis.legend()

    axis.bar_label(
        on_time_bars,
        labels=[
            f"{value:.1f}%"
            for value in departure_summary[
                "On_Time_Rate_Percent"
            ]
        ],
        padding=3,
        fontsize=8
    )

    axis.bar_label(
        delay_bars,
        labels=[
            f"{value:.1f}%"
            for value in departure_summary[
                "Delay_Rate_Percent"
            ]
        ],
        padding=3,
        fontsize=8
    )

    maximum_rate = max(
        departure_summary[
            "On_Time_Rate_Percent"
        ].max(),
        departure_summary[
            "Delay_Rate_Percent"
        ].max()
    )

    axis.set_ylim(
        0,
        maximum_rate + 10
    )

    save_chart(
        figure,
        output_folder,
        "06_departure_time_performance.png"
    )


# ============================================================
# CREATE ROUTE RISK PERFORMANCE CHART
# ============================================================

def create_route_risk_performance_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Compare performance across route-risk categories."""

    route_risk_summary = (
        build_grouped_performance_summary(
            flight_data,
            ["Route_Risk_Category"]
        )
    )

    route_risk_order = [
        "Low Risk",
        "Moderate Risk",
        "High Risk",
        "Not Rated",
        "Review Invalid Route"
    ]

    route_risk_summary[
        "Route_Risk_Category"
    ] = pd.Categorical(
        route_risk_summary[
            "Route_Risk_Category"
        ],
        categories=route_risk_order,
        ordered=True
    )

    route_risk_summary = (
        route_risk_summary
        .sort_values(
            by="Route_Risk_Category"
        )
        .dropna(
            subset=[
                "Route_Risk_Category"
            ]
        )
        .reset_index(drop=True)
    )

    positions = list(
        range(len(route_risk_summary))
    )

    bar_width = 0.36

    left_positions = [
        position - bar_width / 2
        for position in positions
    ]

    right_positions = [
        position + bar_width / 2
        for position in positions
    ]

    figure, axis = plt.subplots(
        figsize=(12, 7)
    )

    on_time_bars = axis.bar(
        left_positions,
        route_risk_summary[
            "On_Time_Rate_Percent"
        ],
        width=bar_width,
        label="On-time rate"
    )

    delay_bars = axis.bar(
        right_positions,
        route_risk_summary[
            "Delay_Rate_Percent"
        ],
        width=bar_width,
        label="Delay rate"
    )

    axis.set_title(
        "Performance by Route Risk Category",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "Route Risk Category",
        fontsize=11
    )

    axis.set_ylabel(
        "Rate (%)",
        fontsize=11
    )

    axis.set_xticks(
        positions
    )

    axis.set_xticklabels(
        route_risk_summary[
            "Route_Risk_Category"
        ]
        .astype(str),
        rotation=20,
        ha="right"
    )

    axis.grid(
        axis="y",
        alpha=0.25
    )

    axis.legend()

    axis.bar_label(
        on_time_bars,
        labels=[
            f"{value:.1f}%"
            for value in route_risk_summary[
                "On_Time_Rate_Percent"
            ]
        ],
        padding=3,
        fontsize=8
    )

    axis.bar_label(
        delay_bars,
        labels=[
            f"{value:.1f}%"
            for value in route_risk_summary[
                "Delay_Rate_Percent"
            ]
        ],
        padding=3,
        fontsize=8
    )

    maximum_rate = max(
        route_risk_summary[
            "On_Time_Rate_Percent"
        ].max(),
        route_risk_summary[
            "Delay_Rate_Percent"
        ].max()
    )

    axis.set_ylim(
        0,
        maximum_rate + 10
    )

    save_chart(
        figure,
        output_folder,
        "07_route_risk_performance.png"
    )


# ============================================================
# CREATE DISTANCE CATEGORY PERFORMANCE CHART
# ============================================================

def create_distance_category_performance_chart(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Compare performance across distance categories."""

    distance_summary = (
        build_grouped_performance_summary(
            flight_data,
            ["Distance_Category"]
        )
    )

    distance_order = [
        "Short Haul",
        "Medium Haul",
        "Long Haul",
        "Unknown"
    ]

    distance_summary[
        "Distance_Category"
    ] = pd.Categorical(
        distance_summary[
            "Distance_Category"
        ],
        categories=distance_order,
        ordered=True
    )

    distance_summary = (
        distance_summary
        .sort_values(
            by="Distance_Category"
        )
        .dropna(
            subset=[
                "Distance_Category"
            ]
        )
        .reset_index(drop=True)
    )

    positions = list(
        range(len(distance_summary))
    )

    bar_width = 0.36

    left_positions = [
        position - bar_width / 2
        for position in positions
    ]

    right_positions = [
        position + bar_width / 2
        for position in positions
    ]

    figure, axis = plt.subplots(
        figsize=(10, 7)
    )

    on_time_bars = axis.bar(
        left_positions,
        distance_summary[
            "On_Time_Rate_Percent"
        ],
        width=bar_width,
        label="On-time rate"
    )

    delay_bars = axis.bar(
        right_positions,
        distance_summary[
            "Delay_Rate_Percent"
        ],
        width=bar_width,
        label="Delay rate"
    )

    axis.set_title(
        "Flight Performance by Distance Category",
        fontsize=16,
        fontweight="bold"
    )

    axis.set_xlabel(
        "Distance Category",
        fontsize=11
    )

    axis.set_ylabel(
        "Rate (%)",
        fontsize=11
    )

    axis.set_xticks(
        positions
    )

    axis.set_xticklabels(
        distance_summary[
            "Distance_Category"
        ]
        .astype(str)
    )

    axis.grid(
        axis="y",
        alpha=0.25
    )

    axis.legend()

    axis.bar_label(
        on_time_bars,
        labels=[
            f"{value:.1f}%"
            for value in distance_summary[
                "On_Time_Rate_Percent"
            ]
        ],
        padding=3,
        fontsize=9
    )

    axis.bar_label(
        delay_bars,
        labels=[
            f"{value:.1f}%"
            for value in distance_summary[
                "Delay_Rate_Percent"
            ]
        ],
        padding=3,
        fontsize=9
    )

    maximum_rate = max(
        distance_summary[
            "On_Time_Rate_Percent"
        ].max(),
        distance_summary[
            "Delay_Rate_Percent"
        ].max()
    )

    axis.set_ylim(
        0,
        maximum_rate + 10
    )

    save_chart(
        figure,
        output_folder,
        "08_distance_category_performance.png"
    )


# ============================================================
# CREATE ALL ADVANCED CHARTS
# ============================================================

def create_advanced_charts(
    flight_data: pd.DataFrame,
    output_folder: Path
) -> None:
    """Create all Phase 5, Part 4 charts."""

    print("\nADVANCED PYTHON CHART CREATION")
    print("-" * 70)

    create_airline_reliability_chart(
        flight_data,
        output_folder
    )

    create_departure_time_performance_chart(
        flight_data,
        output_folder
    )

    create_route_risk_performance_chart(
        flight_data,
        output_folder
    )

    create_distance_category_performance_chart(
        flight_data,
        output_folder
    )


# ============================================================
# BUILD AIRLINE EXPORT SUMMARY
# ============================================================

def build_airline_export_summary(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Build the final airline performance export table."""

    airline_summary = (
        build_grouped_performance_summary(
            flight_data,
            [
                "Airline_Code",
                "Airline_Name"
            ]
        )
    )

    airline_summary["Reliability_Rank"] = (
        airline_summary[
            "On_Time_Rate_Percent"
        ]
        .rank(
            method="min",
            ascending=False
        )
        .astype(int)
    )

    airline_summary = (
        airline_summary
        .sort_values(
            by=[
                "Reliability_Rank",
                "Average_Arrival_Delay"
            ],
            ascending=[
                True,
                True
            ]
        )
        .reset_index(drop=True)
    )

    return airline_summary


# ============================================================
# BUILD ORIGIN AIRPORT EXPORT SUMMARY
# ============================================================

def build_origin_airport_export_summary(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Build the final valid origin-airport export table."""

    valid_origin_data = flight_data.loc[
        flight_data["Origin_Airport_Valid"]
        .fillna(False)
    ].copy()

    airport_summary = (
        build_grouped_performance_summary(
            valid_origin_data,
            [
                "Origin_Airport",
                "Origin_City",
                "Origin_State"
            ]
        )
    )

    airport_summary = (
        airport_summary
        .sort_values(
            by=[
                "Delay_Rate_Percent",
                "Average_Departure_Delay" 
            ],
            ascending=[
                False,
                False
            ]
        )
        .reset_index(drop=True)
    )

    return airport_summary


# ============================================================
# BUILD MONTHLY EXPORT SUMMARY
# ============================================================

def build_monthly_export_summary(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Build monthly trends and comparison metrics."""

    monthly_summary = (
        build_grouped_performance_summary(
            flight_data,
            [
                "Year",
                "Month"
            ]
        )
    )

    monthly_summary["Year"] = pd.to_numeric(
        monthly_summary["Year"],
        errors="coerce"
    ).astype("int64")

    monthly_summary["Month"] = pd.to_numeric(
        monthly_summary["Month"],
        errors="coerce"
    ).astype("int64")

    month_name_map = {
        1: "January",
        2: "February",
        3: "March",
        4: "April",
        5: "May",
        6: "June",
        7: "July",
        8: "August",
        9: "September",
        10: "October",
        11: "November",
        12: "December"
    }

    monthly_summary["Month_Name"] = (
        monthly_summary["Month"]
        .map(month_name_map)
        .fillna("Unknown")
    )

    monthly_summary = (
        monthly_summary
        .sort_values(
            by=[
                "Year",
                "Month"
            ]
        )
        .reset_index(drop=True)
    )

    monthly_summary[
        "Three_Month_On_Time_Average"
    ] = (
        monthly_summary[
            "On_Time_Rate_Percent"
        ]
        .rolling(
            window=3,
            min_periods=1
        )
        .mean()
        .round(2)
    )

    monthly_summary[
        "Three_Month_Arrival_Delay_Average"
    ] = (
        monthly_summary[
            "Average_Arrival_Delay"
        ]
        .rolling(
            window=3,
            min_periods=1
        )
        .mean()
        .round(2)
    )

    monthly_summary[
        "Previous_Month_On_Time_Rate"
    ] = (
        monthly_summary[
            "On_Time_Rate_Percent"
        ]
        .shift(1)
    )

    monthly_summary[
        "On_Time_Rate_Change"
    ] = (
        monthly_summary[
            "On_Time_Rate_Percent"
        ]
        -
        monthly_summary[
            "Previous_Month_On_Time_Rate"
        ]
    ).round(2)

    monthly_summary[
        "Previous_Month_Arrival_Delay"
    ] = (
        monthly_summary[
            "Average_Arrival_Delay"
        ]
        .shift(1)
    )

    monthly_summary[
        "Arrival_Delay_Change"
    ] = (
        monthly_summary[
            "Average_Arrival_Delay"
        ]
        -
        monthly_summary[
            "Previous_Month_Arrival_Delay"
        ]
    ).round(2)

    def classify_monthly_trend(
        row: pd.Series
    ) -> str:
        """Classify monthly on-time performance change."""

        previous_rate = (
            row["Previous_Month_On_Time_Rate"]
        )

        current_rate = (
            row["On_Time_Rate_Percent"]
        )

        if pd.isna(previous_rate):
            return "No Previous Month"

        if current_rate > previous_rate:
            return "Improved"

        if current_rate < previous_rate:
            return "Declined"

        return "No Change"

    monthly_summary[
        "Monthly_Performance_Trend"
    ] = (
        monthly_summary.apply(
            classify_monthly_trend,
            axis=1
        )
    )

    return monthly_summary


# ============================================================
# BUILD SEGMENT EXPORT SUMMARY
# ============================================================

def build_segment_export_summary(
    flight_data: pd.DataFrame
) -> pd.DataFrame:
    """Combine major analysis segment summaries."""

    segment_columns = [
        "Season",
        "Departure_Time_Category",
        "Distance_Category",
        "Route_Risk_Category"
    ]

    segment_tables = []

    for column_name in segment_columns:
        segment_summary = (
            build_grouped_performance_summary(
                flight_data,
                [column_name]
            )
        )

        segment_summary = (
            segment_summary.rename(
                columns={
                    column_name: "Segment_Value"
                }
            )
        )

        segment_summary.insert(
            0,
            "Segment_Type",
            column_name
        )

        segment_tables.append(
            segment_summary
        )

    combined_segment_summary = pd.concat(
        segment_tables,
        ignore_index=True
    )

    combined_segment_summary = (
        combined_segment_summary
        .sort_values(
            by=[
                "Segment_Type",
                "Delay_Rate_Percent"
            ],
            ascending=[
                True,
                False
            ]
        )
        .reset_index(drop=True)
    )

    return combined_segment_summary


# ============================================================
# EXPORT PYTHON ANALYSIS OUTPUTS
# ============================================================

def export_python_analysis_outputs(
    flight_data: pd.DataFrame,
    output_folder: Path,
    charts_folder: Path
) -> None:
    """Export Python analysis tables and final EDA summary."""

    output_folder.mkdir(
        parents=True,
        exist_ok=True
    )

    airline_summary = (
        build_airline_export_summary(
            flight_data
        )
    )

    airport_summary = (
        build_origin_airport_export_summary(
            flight_data
        )
    )

    monthly_summary = (
        build_monthly_export_summary(
            flight_data
        )
    )

    segment_summary = (
        build_segment_export_summary(
            flight_data
        )
    )

    airline_output_path = (
        output_folder
        /
        "01_airline_performance_summary.csv"
    )

    airport_output_path = (
        output_folder
        /
        "02_origin_airport_performance_summary.csv"
    )

    monthly_output_path = (
        output_folder
        /
        "03_monthly_performance_summary.csv"
    )

    segment_output_path = (
        output_folder
        /
        "04_segment_performance_summary.csv"
    )

    summary_output_path = (
        output_folder
        /
        "05_python_eda_summary.txt"
    )

    airline_summary.to_csv(
        airline_output_path,
        index=False,
        encoding="utf-8-sig"
    )

    airport_summary.to_csv(
        airport_output_path,
        index=False,
        encoding="utf-8-sig"
    )

    monthly_summary.to_csv(
        monthly_output_path,
        index=False,
        encoding="utf-8-sig"
    )

    segment_summary.to_csv(
        segment_output_path,
        index=False,
        encoding="utf-8-sig"
    )

    total_flights = len(
        flight_data
    )

    on_time_flights = int(
        flight_data["_On_Time_Record"]
        .sum()
    )

    delayed_flights = int(
        flight_data["_Delayed_Record"]
        .sum()
    )

    cancelled_flights = int(
        flight_data["_Cancelled_Record"]
        .sum()
    )

    diverted_flights = int(
        flight_data["_Diverted_Record"]
        .sum()
    )

    on_time_rate = (
        100
        *
        on_time_flights
        /
        total_flights
    )

    delay_rate = (
        100
        *
        delayed_flights
        /
        total_flights
    )

    cancellation_rate = (
        100
        *
        cancelled_flights
        /
        total_flights
    )

    average_departure_delay = (
        flight_data[
            "_Completed_Departure_Delay"
        ]
        .mean()
    )

    average_arrival_delay = (
        flight_data[
            "_Completed_Arrival_Delay"
        ]
        .mean()
    )

    best_airline = (
        airline_summary.iloc[0]
    )

    worst_airline = (
        airline_summary.iloc[-1]
    )

    best_month = (
        monthly_summary.loc[
            monthly_summary[
                "On_Time_Rate_Percent"
            ]
            .idxmax()
        ]
    )

    worst_month = (
        monthly_summary.loc[
            monthly_summary[
                "On_Time_Rate_Percent"
            ]
            .idxmin()
        ]
    )

    departure_segment = (
        segment_summary.loc[
            segment_summary[
                "Segment_Type"
            ]
            .eq(
                "Departure_Time_Category"
            )
        ]
    )

    best_departure_period = (
        departure_segment.loc[
            departure_segment[
                "On_Time_Rate_Percent"
            ]
            .idxmax()
        ]
    )

    worst_departure_period = (
        departure_segment.loc[
            departure_segment[
                "Delay_Rate_Percent"
            ]
            .idxmax()
        ]
    )

    distance_segment = (
        segment_summary.loc[
            segment_summary[
                "Segment_Type"
            ]
            .eq(
                "Distance_Category"
            )
        ]
    )

    best_distance_category = (
        distance_segment.loc[
            distance_segment[
                "On_Time_Rate_Percent"
            ]
            .idxmax()
        ]
    )

    chart_files = sorted(
        charts_folder.glob("*.png")
    )

    export_timestamp = (
        pd.Timestamp.now()
        .strftime("%Y-%m-%d %H:%M:%S")
    )

    summary_lines = [
        "=" * 70,
        "AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM",
        "PYTHON EXPLORATORY DATA ANALYSIS SUMMARY",
        "=" * 70,
        "",
        f"Export timestamp: {export_timestamp}",
        "",
        "DATASET PROFILE",
        "-" * 70,
        f"Total flight records: {total_flights:,}",
        (
            "Unique flight IDs: "
            f"{flight_data['Flight_ID'].nunique():,}"
        ),
        (
            "Repeated Flight_ID records: "
            f"{total_flights - flight_data['Flight_ID'].nunique():,}"
        ),
        (
            "Unique airlines: "
            f"{flight_data['Airline_Code'].nunique():,}"
        ),
        (
            "Unique origin airports: "
            f"{flight_data['Origin_Airport'].nunique():,}"
        ),
        (
            "Unique destination airports: "
            f"{flight_data['Destination_Airport'].nunique():,}"
        ),
        (
            "Unique routes: "
            f"{flight_data['Route'].nunique():,}"
        ),
        "",
        "OVERALL FLIGHT PERFORMANCE",
        "-" * 70,
        f"On-time flights: {on_time_flights:,}",
        f"Delayed flights: {delayed_flights:,}",
        f"Cancelled flights: {cancelled_flights:,}",
        f"Diverted flights: {diverted_flights:,}",
        f"On-time rate: {on_time_rate:.2f}%",
        f"Delay rate: {delay_rate:.2f}%",
        (
            "Cancellation rate: "
            f"{cancellation_rate:.2f}%"
        ),
        (
            "Average departure delay: "
            f"{average_departure_delay:.2f} minutes"
        ),
        (
            "Average arrival delay: "
            f"{average_arrival_delay:.2f} minutes"
        ),
        "",
        "KEY AIRLINE FINDINGS",
        "-" * 70,
        (
            "Highest-ranked airline: "
            f"{best_airline['Airline_Name']} "
            f"({best_airline['Airline_Code']})"
        ),
        (
            "Highest-ranked airline on-time rate: "
            f"({best_airline['On_Time_Rate_Percent']:.2f}%"
        ),
        (
            "Lowest-ranked airline: "
            f"{worst_airline['Airline_Name']} "
            f"({worst_airline['Airline_Code']})"
        ),
        (
            "Lowest-ranked airline on-time rate: "
            f"{worst_airline['On_Time_Rate_Percent']:.2f}%"
        ),
        "",
        "MONTHLY PERFORMANCE FINDINGS",
        "-" * 70,
        (
            "Best-performing month: "
            f"{best_month['Month_Name']} "
            f"{int(best_month['Year'])}"
        ),
        (
            "Best month on-time rate: "
            f"{best_month['On_Time_Rate_Percent']:.2f}%"
        ),
        (
            "Lowest-performing month: "
            f"{worst_month['Month_Name']} "
            f"{int(worst_month['Year'])}"
        ),
        (
            "Lowest month on-time rate: "
            f"{worst_month['On_Time_Rate_Percent']:.2f}%"
        ),
        "",
        "SEGMENT FINDINGS",
        "-" * 70,
        (
            "Best departure period: "
            f"{best_departure_period['Segment_Value']}"
        ),
        (
            "Best departure-period on-time rate: "
            f"{best_departure_period['On_Time_Rate_Percent']:.2f}%"
        ),
        (
            "Highest-delay departure period: "
            f"{worst_departure_period['Segment_Value']}"
        ),
        (
            "Highest departure-period delay rate: "
            f"{worst_departure_period['Delay_Rate_Percent']:.2f}%"
        ),
        (
            "Best distance category: "
            f"{best_distance_category['Segment_Value']}"
        ),
        (
            "Best distance-category on-time rate: "
            f"{best_distance_category['On_Time_Rate_Percent']:.2f}%"
        ),
        "",
        "EXPORTED PYTHON CHARTS",
        "-" * 70
    ]

    for chart_file in chart_files:
        summary_lines.append(
            chart_file.name
        )
    summary_lines.extend(
        [
            "",
            "PYTHON ANALYSIS TECHNIQUES USED",
            "-" * 70,
            "1. Data type preparation and validation.",
            "2. Missing-value and descriptive-statistics review.",
            "3. Grouped performance aggregation.",
            "4. Airline and airport comparisons.",
            "5. Monthly trend and moving-average analysis.",
            "6. Month-over-month performance comparisons.",
            "7. Segment performance analysis.",
            "8. Scatter, bar, and line visualization.",
            "9. High-resolution chart export.",
            "10. Reusable CSV summary export.",
            "",
            "IMPORTANT DATA-QUALITY NOTES",
            "-" * 70,
            (
                "Five repeated Flight_ID records remain because "
                "the associated rows are not exact duplicates."
            ),
            (
                "Invalid routes were retained and flagged for "
                "review rather than deleted."
            ),
            (
                "Missing cancellation codes are expected for "
                "non-cancelled flights." 
            ),
            (
                "Missing actual-time and delay values are expected "
                "for certain cancelled flights."
            ),
            (
                "Negative delay values may indicate early flight "
                "departures or arrivals."
            ),
            "",
            "=" * 70,
            "PHASE 5 PYTHON EDA COMPLETED",
            "=" * 70
        ]
    )

    summary_text = "\n".join(
        str(line)
        for line in summary_lines
    )

    summary_output_path.write_text(
        summary_text,
        encoding="utf-8"
    )

    print("\nPYTHON ANALYSIS EXPORT")
    print("-" * 70)

    print(
        "Exported successfully: "
        f"{airline_output_path.name}"
    )

    print(
        "Exported successfully: "
        f"{airport_output_path.name}"
    )

    print(
        "Exported successfully: "
        f"{monthly_output_path.name}"
    )

    print(
        "Exported successfully: "
        f"{segment_output_path.name}"
    )

    print(
        "Exported successfully: "
        f"{summary_output_path.name}"
    )
                
                        
# ============================================================
# MAIN PROGRAM
# ============================================================

def main() -> None:
    """Run Phase 5, Part 1 of the exploratory analysis."""

    try:
        flight_data = load_cleaned_dataset(
            CLEANED_DATA_FILE
        )

        flight_data = prepare_analysis_data_types(
            flight_data
        )

        validate_required_columns(
            flight_data
        )

        display_dataset_profile(
            flight_data
        )

        display_data_type_summary(
            flight_data
        )

        display_missing_value_summary(
            flight_data
        )

        display_numeric_summary(
            flight_data
        )

        display_category_summary(
            flight_data
        )

        performance_data = prepare_performance_metrics(
            flight_data
        )

        display_overall_performance_summary(
            performance_data
        )

        display_airline_performance_summary(
            performance_data
        )

        display_origin_airport_performance(
            performance_data
        )

        display_monthly_performance(
            performance_data
        )

        display_segment_performance(
            performance_data
        )

        create_core_charts(
            performance_data,
            PYTHON_CHARTS_FOLDER
        )

        create_advanced_charts(
            performance_data,
            PYTHON_CHARTS_FOLDER
        )

        export_python_analysis_outputs(
            performance_data,
            PYTHON_ANALYSIS_FOLDER,
            PYTHON_CHARTS_FOLDER
        )

        print("\n" + "=" * 70)
        print("PHASE 5, PART 5 COMPLETED SUCCESSFULLY")
        print("=" * 70)

    except FileNotFoundError as error:
        print("\nFILE ERROR")
        print("-" * 70)
        print(error)

    except KeyError as error:
        print("\nCOLUMN ERROR")
        print("-" * 70)
        print(
            "A required column could not be found:"
        )
        print(error)

    except Exception as error:
        print("\nUNEXPECTED ERROR")
        print("-" * 70)
        print(type(error).__name__)
        print(error)


if __name__ == "__main__":
    main()
        
        











































