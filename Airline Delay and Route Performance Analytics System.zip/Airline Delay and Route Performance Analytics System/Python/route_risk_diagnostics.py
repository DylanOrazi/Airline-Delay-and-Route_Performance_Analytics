import pandas as pd
from pathlib import Path

csv_path = (
    Path(__file__).resolve().parent.parent
    / "Data"
    / "Cleaned"
    / "Airline_Delay_and_Route_Performance_Cleaned.csv"
)

df = pd.read_csv(csv_path)

print("\nRoute Delay Rate Distribution:")
print(df["Route_Delay_Rate"].describe())

print("\nRoute Average Arrival Delay Distribution:")
print(df["Route_Average_Arrival_Delay"].describe())

print("\nCurrent Route Risk Categories:")
print(df["Route_Risk_Category"].value_counts(dropna=False))

import numpy as np

valid = df["Route_Valid"].astype(str).str.lower().eq("true")

delay_rate = df["Route_Delay_Rate"]
avg_delay = df["Route_Average_Arrival_Delay"]

conditions = [
    ~valid,
    delay_rate.isna() | avg_delay.isna(),
    (delay_rate >= 0.75) | (avg_delay >= 40),
    (delay_rate >= 0.55) | (avg_delay >= 25)
]

choices = [
    "Review Invalid Route",
    "Not Rated",
    "High Risk",
    "Moderate Risk"
]

df["Proposed_Risk_Category"] = np.select(
    conditions,
    choices,
    default="Low Risk"
)

print("\nProposed Route Risk Categories:")
print(df["Proposed_Risk_Category"].value_counts(dropna=False))