-- ============================================================
-- AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM
-- DATABASE VALIDATION SCRIPT
-- File: 01_database_validation.sql
-- ============================================================


-- ============================================================
-- 1. VERIFY THE TOTAL NUMBER OF IMPORTED RECORDS
-- ============================================================

SELECT
    COUNT(*) AS total_flight_records
FROM flights;


-- ============================================================
-- 2. INSPECT THE IMPORTED TABLE SCHEMA
-- ============================================================

PRAGMA table_info(flights);


-- ============================================================
-- 3. CHECK THE FLIGHT DATE RANGE
-- ============================================================

SELECT
    MIN(Flight_Date) AS earliest_flight_date,
    MAX(Flight_Date) AS latest_flight_date,
    COUNT(DISTINCT Flight_Date) AS distinct_flight_dates
FROM flights;


-- ============================================================
-- 4. CHECK FOR DUPLICATE FLIGHT IDS
-- ============================================================

SELECT
    Flight_ID,
    COUNT(*) AS duplicate_count
FROM flights
GROUP BY Flight_ID
HAVING COUNT(*) > 1
ORDER BY duplicate_count DESC,
    Flight_ID;
    

-- ============================================================
-- 5. COUNT UNIQUE FLIGHT IDS
-- ============================================================

SELECT
    COUNT(*) AS total_records,
    COUNT(DISTINCT Flight_ID) AS unique_flight_ids,
    COUNT(*) - COUNT(DISTINCT Flight_ID)
        AS duplicate_flight_id_records
FROM flights;

-- ============================================================
-- 6. CHECK IMPORTANT MISSING VALUES
-- ============================================================


SELECT
    SUM(
        CASE
            WHEN Flight_ID IS NULL
              OR TRIM(CAST(Flight_ID AS TEXT)) = ''
            THEN 1
            ELSE 0
        END
    ) AS missing_flight_ids,
    
    SUM(
        CASE
            WHEN Flight_Date IS NULL
              OR TRIM(CAST(Flight_Date AS TEXT)) = ''
            THEN 1
            ELSE 0
        END
    ) AS missing_flight_dates,

    SUM(
        CASE
            WHEN Airline_Code IS NULL
              OR TRIM(CAST(Airline_Code AS TEXT)) = ''
            THEN 1
            ELSE 0
        END
    ) AS missing_airline_codes,

    SUM(
        CASE
            WHEN Origin_Airport IS NULL
              OR TRIM(CAST(Origin_Airport AS TEXT)) = ''
            THEN 1
            ELSE 0
        END
    ) AS missing_origin_airports,

    SUM(
        CASE
            WHEN Destination_Airport IS NULL
              OR TRIM(CAST(Destination_Airport AS TEXT)) = ''
            THEN 1
            ELSE 0
        END
    ) AS missing_destination_airports,

    SUM(
        CASE
            WHEN Route IS NULL
              OR TRIM(CAST(Route AS TEXT)) = ''
            THEN 1
            ELSE 0
        END
    ) AS missing_routes

FROM flights;

-- ============================================================
-- 7. VALIDATE FLIGHT STATUS CATEGORIES
-- ============================================================


SELECT
    Flight_Status,
    COUNT(*) AS flight_count,
    ROUND(
        100.0 * COUNT(*) /
        (SELECT COUNT(*) FROM flights),
        2
    ) AS percentage_of_flights
FROM flights
GROUP BY Flight_Status
ORDER BY flight_count DESC;


-- ============================================================
-- 8. VALIDATE DELAY-SEVERITY CATEGORIES
-- ============================================================

SELECT
    Delay_Severity,
    COUNT(*) AS flight_count
FROM flights
GROUP BY Delay_Severity
ORDER BY flight_count DESC;


-- ============================================================
-- 9. VALIDATE CANCELLATION REASONS
-- ============================================================

SELECT
    Cancellation_Reason,
    COUNT(*) AS flight_count
FROM flights
GROUP BY Cancellation_Reason
ORDER BY flight_count DESC;


-- ============================================================
-- 10. VALIDATE ROUTE-RISK CATEGORIES
-- ============================================================

SELECT
    Route_Risk_Category,
    COUNT(*) AS flight_count
FROM flights
GROUP BY Route_Risk_Category
ORDER BY flight_count DESC;


-- ============================================================
-- 11. VALIDATE DISTANCE CATEGORIES
-- ============================================================

SELECT
    Distance_Category,
    COUNT(*) AS flight_count
FROM flights
GROUP BY Distance_Category
ORDER BY flight_count DESC;


-- ============================================================
-- 12. VALIDATE DEPARTURE-TIME CATEGORIES
-- ============================================================

SELECT
    Departure_Time_Category,
    COUNT(*) AS flight_count
FROM flights
GROUP BY Departure_Time_Category
ORDER BY flight_count DESC;


-- ============================================================
-- 13. VALIDATE SEASON CATEGORIES
-- ============================================================

SELECT
    Season,
    COUNT(*) AS flight_count
FROM flights
Group BY Season
ORDER BY flight_count DESC;


-- ============================================================
-- 14. COUNT AIRLINES, AIRPORTS, AND ROUTES
-- ============================================================

SELECT 
    COUNT(DISTINCT Airline_Code)
        AS distinct_airlines,
        
    COUNT(DISTINCT Origin_Airport)
        AS distinct_origin_airports,
            
    COUNT(DISTINCT Destination_Airport)
        AS distinct_destination_airports,
        
    COUNT(DISTINCT Route)
        AS distinct_routes
        
FROM flights;


-- ============================================================
-- 15. REVIEW AIRLINE RECORD COUNTS
-- ============================================================

SELECT
    Airline_Code,
    Airline_Name,
    COUNT(*) AS flight_count
FROM flights
GROUP BY
    Airline_Code,
    Airline_Name
ORDER BY flight_count DESC;


-- ============================================================
-- 16. COUNT INVALID AIRPORT AND ROUTE RECORDS
-- Handles either True/False text or 1/0 values.
-- ============================================================

SELECT
    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Origin_Airport_Valid AS TEXT
                    )
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS invalid_origin_records,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Destination_Airport_Valid AS TEXT
                    )
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS invalid_destination_records,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Route_Valid AS TEXT
                    )
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS invalid_route_records

FROM flights;


-- ============================================================
-- 17. DISPLAY INVALID ROUTES REQUIRING REVIEW
-- ============================================================

SELECT
    Flight_ID,
    Flight_Date,
    Airline_Code,
    Origin_Airport,
    Destination_Airport,
    Route,
    Origin_Airport_Valid,
    Destination_Airport_Valid,
    Route_Valid
FROM flights
WHERE LOWER(
    TRIM(
        CAST(Route_Valid AS TEXT)
    )
) IN ('flase', '0')
ORDER BY
    Origin_Airport,
    Destination_Airport,
    Flight_ID;
    

-- ============================================================
-- 18. COUNT CANCELLATION-CODE VALIDATION ISSUES
-- ============================================================

SELECT
    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Cancellation_Code_Valid AS TEXT
                    )
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS invalid_cancellation_code_records
FROM flights;


-- ============================================================
-- 19. COUNT DELAY OUTLIER RECORDS
-- ============================================================

SELECT
    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Delay_Outlier_Flag AS TEXT
                    )
                )
            ) IN ('true', '1')
            THEN 1
            ELSE 0
        END
    ) AS delay_outlier_records
FROM flights;


-- ============================================================
-- 20. DISPLAY DELAY OUTLIERS REQUIRING REVIEW
-- ============================================================

SELECT
    Flight_ID,
    Flight_Date,
    Airline_Code,
    Route,
    Departure_Delay_Minutes,
    Arrival_Delay_Minutes,
    Departure_Delay_Outlier,
    Arrival_Delay_Outlier,
    Delay_Outlier_Reason
FROM flights
WHERE LOWER(
    TRIM(
        CAST(Delay_Outlier_Flag AS TEXT)
    )
) IN ('true', '1')
ORDER BY
    Arrival_Delay_Minutes DESC,
    Departure_Delay_Minutes DESC;
    

-- ============================================================
-- 21. CHECK NUMERIC VALUE RANGES
-- ============================================================
    
SELECT
    MIN(Distance_Miles)
        AS minimum_distance_miles,
        
    MAX(Distance_Miles)
        AS maximum_distance_miles,
        
    MIN(Departure_Delay_Minutes)
        AS minimum_departure_delay,
        
    MAX(Departure_Delay_Minutes)
        AS maximum_departure_delay,
        
    MIN(Arrival_Delay_Minutes)
        AS minimum_arrival_delay,
        
    MAX(Arrival_Delay_Minutes)
        AS maximum_arrival_delay
        
FROM flights;

-- ============================================================
-- 22. CHECK PERFORMANCE INDICATOR TOTALS
-- Handles either True/False text or 1/0 values.
-- ============================================================

SELECT
    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(On_Time_Flag AS TEXT)
                )
            ) IN ('true', '1')
            THEN 1
            ELSE 0
        END
    ) AS on_time_flights,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(Delayed_Flag AS TEXT)
                )
            ) IN ('true', '1')
            THEN 1
            ELSE 0
        END
    ) AS delayed_flights,

    SUM(
        CASE
            WHEN CAST(Cancelled AS INTEGER) = 1
            THEN 1
            ELSE 0
        END
    ) AS cancelled_flights,

    SUM(
        CASE
            WHEN CAST(Diverted AS INTEGER) = 1
            THEN 1
            ELSE 0
        END
    ) AS diverted_flights

FROM flights;


-- ============================================================
-- 23. VERIFY THAT STATUS TOTALS MATCH THE TABLE ROW COUNT
-- ============================================================

SELECT
    COUNT(*) AS total_records,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS on_time_records,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS delayed_records,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS cancelled_records,

    SUM(
        CASE
            WHEN Flight_Status = 'Diverted'
            THEN 1
            ELSE 0
        END
    ) AS diverted_records,

    SUM(
        CASE
            WHEN Flight_Status IN (
                'On Time',
                'Delayed',
                'Cancelled',
                'Diverted'
            )
            THEN 1
            ELSE 0
        END
    ) AS recognized_status_records

FROM flights;


-- ============================================================
-- 24. FIND ANY UNEXPECTED FLIGHT STATUS VALUES
-- ============================================================

SELECT
    Flight_Status,
    COUNT(*) AS flight_count
FROM flights
WHERE Flight_Status NOT IN (
    'On Time',
    'Delayed',
    'Cancelled',
    'Diverted'
)
   OR Flight_Status IS NULL
   OR TRIM(Flight_Status) = ''
GROUP BY Flight_Status;


-- ============================================================
-- 25. FINAL DATABASE VALIDATION SUMMARY
-- ============================================================

SELECT
    COUNT(*) AS total_records,
    
    COUNT(DISTINCT Flight_ID)
        AS unique_flight_ids,
        
    COUNT(DISTINCT Airline_Code)
        AS airlines,
        
    COUNT(DISTINCT Route)
        AS routes,
        
    MIN(Flight_Date)
        AS earliest_date,
        
    MAX(Flight_Date)
        AS latest_date
        
FROM flights;

































