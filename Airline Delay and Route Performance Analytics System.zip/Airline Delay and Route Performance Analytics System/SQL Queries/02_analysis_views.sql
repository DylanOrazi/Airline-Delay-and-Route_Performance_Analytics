-- ============================================================
-- AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM
-- ANALYSIS VIEW CREATION SCRIPT
-- File: 02_analysis_views.sql
-- ============================================================


-- ============================================================
-- REMOVE EXISTING VIEWS BEFORE RECREATING THEM
-- ============================================================

DROP VIEW IF EXISTS vw_flight_analysis;
DROP VIEW IF EXISTS vw_airline_performance;
DROP VIEW IF EXISTS vw_airport_performance;
DROP VIEW IF EXISTS vw_route_performance;


-- ============================================================
-- 1. FLIGHT-LEVEL ANALYSIS VIEW
-- ============================================================

CREATE VIEW vw_flight_analysis AS

SELECT
    Flight_ID,
    Flight_Date,
    Year,
    Quarter,
    Month,
    Day_of_Month,
    Day_of_Week,

    Airline_Code,
    Airline_Name,

    Origin_Airport,
    Origin_City,
    Origin_State,

    Destination_Airport,
    Destination_City,
    Destination_State,

    Route,

    Scheduled_Departure,
    Actual_Departure,
    Scheduled_Departure_Time,
    Actual_Departure_Time,

    Scheduled_Arrival,
    Actual_Arrival,
    Scheduled_Arrival_Time,
    Actual_Arrival_Time,

    Departure_Delay_Minutes,
    Arrival_Delay_Minutes,
    Total_Delay_Minutes,

    Distance_Miles,
    Distance_Category,

    Cancelled,
    Diverted,

    Cancellation_Code,
    Cancellation_Reason,

    Flight_Status,
    Delay_Category,
    Delay_Severity,

    Departure_Time_Category,
    Weekend_Flag,
    Season,

    On_Time_Flag,
    Delayed_Flag,

    Origin_Airport_Valid,
    Destination_Airport_Valid,
    Route_Valid,

    Cancellation_Code_Valid,

    Departure_Delay_Outlier,
    Arrival_Delay_Outlier,
    Delay_Outlier_Flag,
    Delay_Outlier_Reason,

    Route_Delay_Rate,
    Route_Average_Arrival_Delay,
    Route_Risk_Category,

    Data_Source

FROM flights;


-- ============================================================
-- 2. AIRLINE PERFORMANCE VIEW
-- ============================================================

CREATE VIEW vw_airline_performance AS

SELECT
    Airline_Code,
    Airline_Name,
    
    COUNT(*) AS Total_Flights,
    
    SUM(
        Case
            When Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,
    
    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,
    
    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,
    
    SUM(
        CASE
            WHEN Flight_Status = 'Diverted'
            THEN 1
            ELSE 0
        END
    ) AS Diverted_Flights,
    
    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        ) 
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,
    
    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Cancelled'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Cancellation_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Departure_Delay_Minutes
            END
        ),
        2
    ) AS Average_Departure_Delay_Minutes,

    ROUND(
        AVG(Distance_Miles),
        2
    ) AS Average_Distance_Miles,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Delay_Outlier_Flag AS TEXT
                    )
                )
            ) IN ('true', '1')
            THEN 1
            ELSE 0
        END
    ) AS Delay_Outlier_Records

FROM flights

GROUP BY
    Airline_Code,
    Airline_Name;
    

-- ============================================================
-- 3. AIRPORT PERFORMANCE VIEW
-- Each airport is summarized as both an origin and destination.
-- ============================================================

DROP VIEW IF EXISTS vw_airport_performance;

CREATE VIEW vw_airport_performance AS

WITH airport_activity AS (

    SELECT
        Origin_Airport AS Airport_Code,
        Origin_City AS Airport_City,
        Origin_State AS Airport_State,
        'Origin' AS Airport_Role,
        Flight_ID,
        Flight_Status,
        Departure_Delay_Minutes,
        Arrival_Delay_Minutes,
        Distance_Miles,
        Route_Valid
    FROM flights

    UNION ALL

    SELECT
        Destination_Airport AS Airport_Code,
        Destination_City AS Airport_City,
        Destination_State AS Airport_State,
        'Destination' AS Airport_Role,
        Flight_ID,
        Flight_Status,
        Departure_Delay_Minutes,
        Arrival_Delay_Minutes,
        Distance_Miles,
        Route_Valid
    FROM flights
)

SELECT
    Airport_Code,
    Airport_City,
    Airport_State,
    Airport_Role,

    COUNT(*) AS Total_Flight_Records,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Diverted'
            THEN 1
            ELSE 0
        END
    ) AS Diverted_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        AVG(Departure_Delay_Minutes),
        2
    ) AS Average_Departure_Delay_Minutes,

    ROUND(
        AVG(Arrival_Delay_Minutes),
        2
    ) AS Average_Arrival_Delay_Minutes,

    ROUND(
        AVG(Distance_Miles),
        2
    ) AS Average_Distance_Miles,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(Route_Valid AS TEXT)
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS Invalid_Route_Records

FROM airport_activity

GROUP BY
    Airport_Code,
    Airport_City,
    Airport_State,
    Airport_Role;


-- ============================================================
-- 4. ROUTE PERFORMANCE VIEW
-- ============================================================

CREATE VIEW vw_route_performance AS

SELECT
    Route,
    Origin_Airport,
    Origin_City,
    Origin_State,
    Destination_Airport,
    Destination_City,
    Destination_State,

    COUNT(*) AS Total_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Diverted'
            THEN 1
            ELSE 0
        END
    ) AS Diverted_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Cancelled'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Cancellation_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Departure_Delay_Minutes
            END
        ),
        2
    ) AS Average_Departure_Delay_Minutes,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes,

    ROUND(
        AVG(Distance_Miles),
        2
    ) AS Average_Distance_Miles,

    MIN(Distance_Miles) AS Minimum_Distance_Miles,
    MAX(Distance_Miles) AS Maximum_Distance_Miles,

    ROUND(
        AVG(Route_Delay_Rate) * 100,
        2
    ) AS Stored_Route_Delay_Rate_Percent,

    ROUND(
        AVG(Route_Average_Arrival_Delay),
        2
    ) AS Stored_Route_Average_Arrival_Delay,

    MAX(Route_Risk_Category)
        AS Route_Risk_Category,

    MAX(Route_Valid)
        AS Route_Valid

FROM flights

GROUP BY
    Route,
    Origin_Airport,
    Origin_City,
    Origin_State,
    Destination_Airport,
    Destination_City,
    Destination_State;
                











