-- ============================================================
-- AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM
-- CORE ANALYSIS QUERIES
-- File: 03_core_analysis_queries.sql
-- ============================================================


-- ============================================================
-- 1. EXECUTIVE FLIGHT PERFORMANCE SUMMARY
-- ============================================================

SELECT
    COUNT(*) AS Total_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Diverted'
            THEN 1
            ELSE 0
        END
    ) AS Diverted_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Cancelled'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Cancellation_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Departure_Delay_Minutes
            END
        ),
        2
    ) AS Average_Departure_Delay_Minutes,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes,

    ROUND(
        AVG(Distance_Miles),
        2
    ) AS Average_Distance_Miles

FROM vw_flight_analysis;


-- ============================================================
-- 2. AIRLINE PERFORMANCE RANKING
-- Minimum flight threshold prevents tiny samples from
-- receiving misleading rankings.
-- ============================================================

SELECT
    Airline_Code,
    Airline_Name,
    Total_Flights,
    On_Time_Flights,
    Delayed_Flights,
    Cancelled_Flights,
    Diverted_Flights,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Cancellation_Rate_Percent,
    Average_Departure_Delay_Minutes,
    Average_Arrival_Delay_Minutes,
    Delay_Outlier_Records,

    RANK() OVER (
        ORDER BY
            On_Time_Rate_Percent DESC,
            Average_Arrival_Delay_Minutes ASC
    ) AS Reliability_Rank

FROM vw_airline_performance

WHERE Total_Flights >= 100

ORDER BY
    Reliability_Rank,
    Airline_Name;


-- ============================================================
-- 3. ORIGIN-AIRPORT PERFORMANCE
-- ============================================================

SELECT
    Airport_Code,
    Airport_City,
    Airport_State,
    Total_Flight_Records,
    On_Time_Flights,
    Delayed_Flights,
    Cancelled_Flights,
    Diverted_Flights,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Average_Departure_Delay_Minutes,
    Average_Arrival_Delay_Minutes,
    Invalid_Route_Records

FROM vw_airport_performance

WHERE Airport_Role = 'Origin'
  AND Total_Flight_Records >= 100

ORDER BY
    Delay_Rate_Percent DESC,
    Average_Departure_Delay_Minutes DESC;


-- ============================================================
-- 4. DESTINATION-AIRPORT PERFORMANCE
-- ============================================================

SELECT
    Airport_Code,
    Airport_City,
    Airport_State,
    Total_Flight_Records,
    On_Time_Flights,
    Delayed_Flights,
    Cancelled_Flights,
    Diverted_Flights,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Average_Departure_Delay_Minutes,
    Average_Arrival_Delay_Minutes

FROM vw_airport_performance

WHERE Airport_Role = 'Destination'
  AND Total_Flight_Records >= 100

ORDER BY
    Average_Arrival_Delay_Minutes DESC,
    Delay_Rate_Percent DESC;


-- ============================================================
-- 5. HIGHEST-VOLUME ROUTES
-- ============================================================

SELECT
    Route,
    Origin_Airport,
    Origin_City,
    Origin_State,
    Destination_Airport,
    Destination_City,
    Destination_State,
    Total_Flights,
    On_Time_Flights,
    Delayed_Flights,
    Cancelled_Flights,
    Diverted_Flights,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Cancellation_Rate_Percent,
    Average_Arrival_Delay_Minutes,
    Average_Distance_Miles,
    Route_Risk_Category

FROM vw_route_performance

WHERE LOWER(
    TRIM(
        CAST(Route_Valid AS TEXT)
    )
) IN ('true', '1')

ORDER BY
    Total_Flights DESC,
    Route

LIMIT 25;


-- ============================================================
-- 6. HIGHEST-RISK VALID ROUTES
-- A minimum flight count reduces small-sample distortion.
-- ============================================================

SELECT
    Route,
    Origin_Airport,
    Destination_Airport,
    Total_Flights,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Cancellation_Rate_Percent,
    Average_Departure_Delay_Minutes,
    Average_Arrival_Delay_Minutes,
    Stored_Route_Delay_Rate_Percent,
    Stored_Route_Average_Arrival_Delay,
    Route_Risk_Category

FROM vw_route_performance

WHERE LOWER(
    TRIM(
        CAST(Route_Valid AS TEXT)
    )
) IN ('true', '1')

  AND Total_Flights >= 10

ORDER BY
    CASE Route_Risk_Category
        WHEN 'High Risk' THEN 1
        WHEN 'Moderate Risk' THEN 2
        WHEN 'Low Risk' THEN 3
        ELSE 4
    END,
    Delay_Rate_Percent DESC,
    Average_Arrival_Delay_Minutes DESC

LIMIT 25;


-- ============================================================
-- 7. MONTHLY FLIGHT PERFORMANCE TREND
-- ============================================================

SELECT
    CAST(Year AS INTEGER) AS Year,
    CAST(Month AS INTEGER) AS Month,

    CASE CAST(Month AS INTEGER)
        WHEN 1 THEN 'January'
        WHEN 2 THEN 'February'
        WHEN 3 THEN 'March'
        WHEN 4 THEN 'April'
        WHEN 5 THEN 'May'
        WHEN 6 THEN 'June'
        WHEN 7 THEN 'July'
        WHEN 8 THEN 'August'
        WHEN 9 THEN 'September'
        WHEN 10 THEN 'October'
        WHEN 11 THEN 'November'
        WHEN 12 THEN 'December'
        ELSE 'Unknown'
    END AS Month_Name,

    COUNT(*) AS Total_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes

FROM vw_flight_analysis

GROUP BY
    CAST(Year AS INTEGER),
    CAST(Month AS INTEGER)

ORDER BY
    CAST(Year AS INTEGER),
    CAST(Month AS INTEGER);


-- ============================================================
-- 8. SEASONAL PERFORMANCE
-- ============================================================

SELECT
    Season,
    COUNT(*) AS Total_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes

FROM vw_flight_analysis

GROUP BY Season

ORDER BY
    CASE Season
        WHEN 'Winter' THEN 1
        WHEN 'Spring' THEN 2
        WHEN 'Summer' THEN 3
        WHEN 'Fall' THEN 4
        ELSE 5
    END;


-- ============================================================
-- 9. DAY-OF-WEEK PERFORMANCE
-- ============================================================

SELECT
    Day_of_Week,

    CASE Day_of_Week
        WHEN 1 THEN 'Monday'
        WHEN 2 THEN 'Tuesday'
        WHEN 3 THEN 'Wednesday'
        WHEN 4 THEN 'Thursday'
        WHEN 5 THEN 'Friday'
        WHEN 6 THEN 'Saturday'
        WHEN 7 THEN 'Sunday'
        ELSE 'Unknown'
    END AS Day_Name,

    COUNT(*) AS Total_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes

FROM vw_flight_analysis

GROUP BY Day_of_Week

ORDER BY Day_of_Week;


-- ============================================================
-- 10. DEPARTURE-TIME PERFORMANCE
-- ============================================================

SELECT
    Departure_Time_Category,
    COUNT(*) AS Total_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Departure_Delay_Minutes
            END
        ),
        2
    ) AS Average_Departure_Delay_Minutes,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes

FROM vw_flight_analysis

GROUP BY Departure_Time_Category

ORDER BY
    CASE Departure_Time_Category
        WHEN 'Morning' THEN 1
        WHEN 'Afternoon' THEN 2
        WHEN 'Evening' THEN 3
        WHEN 'Night' THEN 4
        ELSE 5
    END;


-- ============================================================
-- 11. CANCELLATION REASON ANALYSIS
-- Only cancelled flights are included.
-- ============================================================

SELECT
    Cancellation_Code,
    Cancellation_Reason,
    COUNT(*) AS Cancelled_Flights,

    ROUND(
        100.0 * COUNT(*) /
        (
            SELECT COUNT(*)
            FROM vw_flight_analysis
            WHERE Flight_Status = 'Cancelled'
        ),
        2
    ) AS Percent_of_Cancellations,

    ROUND(
        AVG(Distance_Miles),
        2
    ) AS Average_Distance_Miles

FROM vw_flight_analysis

WHERE Flight_Status = 'Cancelled'

GROUP BY
    Cancellation_Code,
    Cancellation_Reason

ORDER BY
    Cancelled_Flights DESC,
    Cancellation_Reason;


-- ============================================================
-- 12. DELAY-SEVERITY ANALYSIS
-- ============================================================

SELECT
    Delay_Severity,
    COUNT(*) AS Flight_Count,

    ROUND(
        100.0 * COUNT(*) /
        (SELECT COUNT(*) FROM vw_flight_analysis),
        2
    ) AS Percent_of_All_Flights,

    ROUND(
        AVG(
            CASE
                WHEN Arrival_Delay_Minutes IS NOT NULL
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes,

    ROUND(
        AVG(
            CASE
                WHEN Departure_Delay_Minutes IS NOT NULL
                THEN Departure_Delay_Minutes
            END
        ),
        2
    ) AS Average_Departure_Delay_Minutes

FROM vw_flight_analysis

GROUP BY Delay_Severity

ORDER BY
    CASE Delay_Severity
        WHEN 'Early' THEN 1
        WHEN 'On Time' THEN 2
        WHEN 'Moderate Delay' THEN 3
        WHEN 'Severe Delay' THEN 4
        WHEN 'Extreme Delay' THEN 5
        WHEN 'Not Applicable - Diverted' THEN 6
        WHEN 'Not Applicable - Cancelled' THEN 7
        ELSE 8
    END;


-- ============================================================
-- 13. DISTANCE-CATEGORY PERFORMANCE
-- ============================================================

SELECT
    Distance_Category,
    COUNT(*) AS Total_Flights,

    ROUND(
        AVG(Distance_Miles),
        2
    ) AS Average_Distance_Miles,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes

FROM vw_flight_analysis

GROUP BY Distance_Category

ORDER BY
    CASE Distance_Category
        WHEN 'Short Haul' THEN 1
        WHEN 'Medium Haul' THEN 2
        WHEN 'Long Haul' THEN 3
        ELSE 4
    END;


-- ============================================================
-- 14. WEEKDAY VERSUS WEEKEND PERFORMANCE
-- Handles Boolean values imported as True/False or 1/0.
-- ============================================================

SELECT
    CASE
        WHEN LOWER(
            TRIM(
                CAST(Weekend_Flag AS TEXT)
            )
        ) IN ('true', '1')
        THEN 'Weekend'
        ELSE 'Weekday'
    END AS Day_Type,

    COUNT(*) AS Total_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Flights,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Flights,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'On Time'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS On_Time_Rate_Percent,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN Flight_Status = 'Delayed'
                THEN 1
                ELSE 0
            END
        )
        /
        COUNT(*),
        2
    ) AS Delay_Rate_Percent,

    ROUND(
        AVG(
            CASE
                WHEN Flight_Status NOT IN (
                    'Cancelled',
                    'Diverted'
                )
                THEN Arrival_Delay_Minutes
            END
        ),
        2
    ) AS Average_Arrival_Delay_Minutes

FROM vw_flight_analysis

GROUP BY Day_Type

ORDER BY Day_Type;


-- ============================================================
-- 15. DATA-QUALITY REVIEW SUMMARY
-- ============================================================

SELECT
    COUNT(*) AS Total_Flight_Records,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(Route_Valid AS TEXT)
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS Invalid_Route_Records,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(Cancellation_Code_Valid AS TEXT)
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS Invalid_Cancellation_Code_Records,

    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(Delay_Outlier_Flag AS TEXT)
                )
            ) IN ('true', '1')
            THEN 1
            ELSE 0
        END
    ) AS Delay_Outlier_Records,

    SUM(
        CASE
            WHEN Origin_City = 'Unknown'
            THEN 1
            ELSE 0
        END
    ) AS Unknown_Origin_City_Records

FROM vw_flight_analysis;




