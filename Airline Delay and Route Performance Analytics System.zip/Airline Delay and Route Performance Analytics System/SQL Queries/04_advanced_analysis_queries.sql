-- ============================================================
-- AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM
-- ADVANCED SQL ANALYSIS
-- File: 04_advanced_analysis_queries.sql
-- ============================================================


-- ============================================================
-- 1. AIRLINE PERFORMANCE COMPARED WITH OVERALL PERFORMANCE
-- Uses CTEs and a cross join.
-- ============================================================

WITH overall_performance AS (

    SELECT
        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'On Time'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS Overall_On_Time_Rate,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'Delayed'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS Overall_Delay_Rate,

        ROUND(
            AVG(
                CASE
                    WHEN Flight_Status NOT IN (
                        'Cancelled',
                        'Diverted'
                    )
                    THEN Arrival_Delay_Minutes
                END
            ),
            2
        ) AS Overall_Average_Arrival_Delay

    FROM vw_flight_analysis
),

airline_performance AS (

    SELECT
        Airline_Code,
        Airline_Name,
        COUNT(*) AS Total_Flights,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'On Time'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS Airline_On_Time_Rate,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'Delayed'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS Airline_Delay_Rate,

        ROUND(
            AVG(
                CASE
                    WHEN Flight_Status NOT IN (
                        'Cancelled',
                        'Diverted'
                    )
                    THEN Arrival_Delay_Minutes
                END
            ),
            2
        ) AS Airline_Average_Arrival_Delay

    FROM vw_flight_analysis

    GROUP BY
        Airline_Code,
        Airline_Name
)

SELECT
    a.Airline_Code,
    a.Airline_Name,
    a.Total_Flights,

    a.Airline_On_Time_Rate,
    o.Overall_On_Time_Rate,

    ROUND(
        a.Airline_On_Time_Rate
        -
        o.Overall_On_Time_Rate,
        2
    ) AS On_Time_Rate_Difference,

    a.Airline_Delay_Rate,
    o.Overall_Delay_Rate,

    ROUND(
        a.Airline_Delay_Rate
        -
        o.Overall_Delay_Rate,
        2
    ) AS Delay_Rate_Difference,

    a.Airline_Average_Arrival_Delay,
    o.Overall_Average_Arrival_Delay,

    ROUND(
        a.Airline_Average_Arrival_Delay
        -
        o.Overall_Average_Arrival_Delay,
        2
    ) AS Arrival_Delay_Difference,

    CASE
        WHEN a.Airline_On_Time_Rate
             > o.Overall_On_Time_Rate
        THEN 'Above Average'

        WHEN a.Airline_On_Time_Rate
             < o.Overall_On_Time_Rate
        THEN 'Below Average'

        ELSE 'At Average'
    END AS Reliability_Performance

FROM airline_performance AS a

CROSS JOIN overall_performance AS o

ORDER BY
    On_Time_Rate_Difference DESC,
    Arrival_Delay_Difference ASC;


-- ============================================================
-- 2. MONTHLY PERFORMANCE WITH MOVING AVERAGES
-- Uses CTEs and window functions.
-- ============================================================

WITH monthly_performance AS (

    SELECT
        CAST(Year AS INTEGER) AS Year,
        CAST(Month AS INTEGER) AS Month,

        COUNT(*) AS Total_Flights,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'On Time'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS On_Time_Rate_Percent,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'Delayed'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS Delay_Rate_Percent,

        ROUND(
            AVG(
                CASE
                    WHEN Flight_Status NOT IN (
                        'Cancelled',
                        'Diverted'
                    )
                    THEN Arrival_Delay_Minutes
                END
            ),
            2
        ) AS Average_Arrival_Delay_Minutes

    FROM vw_flight_analysis

    GROUP BY
        CAST(Year AS INTEGER),
        CAST(Month AS INTEGER)
)

SELECT
    Year,
    Month,

    CASE Month
        WHEN 1 THEN 'January'
        WHEN 2 THEN 'February'
        WHEN 3 THEN 'March'
        WHEN 4 THEN 'April'
        WHEN 5 THEN 'May'
        WHEN 6 THEN 'June'
        WHEN 7 THEN 'July'
        WHEN 8 THEN 'August'
        WHEN 9 THEN 'September'
        WHEN 10 THEN 'October'
        WHEN 11 THEN 'November'
        WHEN 12 THEN 'December'
        ELSE 'Unknown'
    END AS Month_Name,

    Total_Flights,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Average_Arrival_Delay_Minutes,

    ROUND(
        AVG(On_Time_Rate_Percent) OVER (
            ORDER BY
                Year,
                Month

            ROWS BETWEEN
                2 PRECEDING
                AND CURRENT ROW
        ),
        2
    ) AS Three_Month_On_Time_Moving_Average,

    ROUND(
        AVG(Average_Arrival_Delay_Minutes) OVER (
            ORDER BY
                Year,
                Month

            ROWS BETWEEN
                2 PRECEDING
                AND CURRENT ROW
        ),
        2
    ) AS Three_Month_Arrival_Delay_Moving_Average

FROM monthly_performance

ORDER BY
    Year,
    Month;


-- ============================================================
-- 3. MONTH-OVER-MONTH PERFORMANCE CHANGE
-- Uses LAG to compare each month with the prior month.
-- ============================================================

WITH monthly_performance AS (

    SELECT
        CAST(Year AS INTEGER) AS Year,
        CAST(Month AS INTEGER) AS Month,

        COUNT(*) AS Total_Flights,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'On Time'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS On_Time_Rate_Percent,

        ROUND(
            AVG(
                CASE
                    WHEN Flight_Status NOT IN (
                        'Cancelled',
                        'Diverted'
                    )
                    THEN Arrival_Delay_Minutes
                END
            ),
            2
        ) AS Average_Arrival_Delay_Minutes

    FROM vw_flight_analysis

    GROUP BY
        CAST(Year AS INTEGER),
        CAST(Month AS INTEGER)
),

monthly_comparison AS (

    SELECT
        Year,
        Month,
        Total_Flights,
        On_Time_Rate_Percent,
        Average_Arrival_Delay_Minutes,

        LAG(On_Time_Rate_Percent) OVER (
            ORDER BY
                Year,
                Month
        ) AS Previous_Month_On_Time_Rate,

        LAG(Average_Arrival_Delay_Minutes) OVER (
            ORDER BY
                Year,
                Month
        ) AS Previous_Month_Arrival_Delay

    FROM monthly_performance
)

SELECT
    Year,
    Month,

    CASE Month
        WHEN 1 THEN 'January'
        WHEN 2 THEN 'February'
        WHEN 3 THEN 'March'
        WHEN 4 THEN 'April'
        WHEN 5 THEN 'May'
        WHEN 6 THEN 'June'
        WHEN 7 THEN 'July'
        WHEN 8 THEN 'August'
        WHEN 9 THEN 'September'
        WHEN 10 THEN 'October'
        WHEN 11 THEN 'November'
        WHEN 12 THEN 'December'
        ELSE 'Unknown'
    END AS Month_Name,

    Total_Flights,
    On_Time_Rate_Percent,
    Previous_Month_On_Time_Rate,

    ROUND(
        On_Time_Rate_Percent
        -
        Previous_Month_On_Time_Rate,
        2
    ) AS On_Time_Rate_Change,

    Average_Arrival_Delay_Minutes,
    Previous_Month_Arrival_Delay,

    ROUND(
        Average_Arrival_Delay_Minutes
        -
        Previous_Month_Arrival_Delay,
        2
    ) AS Arrival_Delay_Change,

    CASE
        WHEN Previous_Month_On_Time_Rate IS NULL
        THEN 'No Previous Month'

        WHEN On_Time_Rate_Percent
             > Previous_Month_On_Time_Rate
        THEN 'Improved'

        WHEN On_Time_Rate_Percent
             < Previous_Month_On_Time_Rate
        THEN 'Declined'

        ELSE 'No Change'
    END AS Monthly_Performance_Trend

FROM monthly_comparison

ORDER BY
    Year,
    Month;


-- ============================================================
-- 4. AIRLINE RANKING BY MULTIPLE PERFORMANCE METRICS
-- Uses multiple ranking window functions.
-- ============================================================

WITH airline_metrics AS (

    SELECT
        Airline_Code,
        Airline_Name,
        COUNT(*) AS Total_Flights,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'On Time'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS On_Time_Rate_Percent,

        ROUND(
            100.0 *
            SUM(
                CASE
                    WHEN Flight_Status = 'Cancelled'
                    THEN 1
                    ELSE 0
                END
            )
            /
            COUNT(*),
            2
        ) AS Cancellation_Rate_Percent,

        ROUND(
            AVG(
                CASE
                    WHEN Flight_Status NOT IN (
                        'Cancelled',
                        'Diverted'
                    )
                    THEN Arrival_Delay_Minutes
                END
            ),
            2
        ) AS Average_Arrival_Delay_Minutes

    FROM vw_flight_analysis

    GROUP BY
        Airline_Code,
        Airline_Name
)

SELECT
    Airline_Code,
    Airline_Name,
    Total_Flights,
    On_Time_Rate_Percent,
    Cancellation_Rate_Percent,
    Average_Arrival_Delay_Minutes,

    RANK() OVER (
        ORDER BY
            On_Time_Rate_Percent DESC
    ) AS On_Time_Rank,

    RANK() OVER (
        ORDER BY
            Cancellation_Rate_Percent ASC
    ) AS Cancellation_Rank,

    RANK() OVER (
        ORDER BY
            Average_Arrival_Delay_Minutes ASC
    ) AS Arrival_Delay_Rank,

    (
        RANK() OVER (
            ORDER BY
                On_Time_Rate_Percent DESC
        )
        +
        RANK() OVER (
            ORDER BY
                Cancellation_Rate_Percent ASC
        )
        +
        RANK() OVER (
            ORDER BY
                Average_Arrival_Delay_Minutes ASC
        )
    ) AS Combined_Rank_Score

FROM airline_metrics

ORDER BY
    Combined_Rank_Score ASC,
    Airline_Name;


-- ============================================================
-- 5. ROUTE VOLUME CONCENTRATION AND CUMULATIVE SHARE
-- Uses cumulative window functions.
-- ============================================================

WITH route_volume AS (

    SELECT
        Route,
        Total_Flights,
        On_Time_Rate_Percent,
        Delay_Rate_Percent,
        Average_Arrival_Delay_Minutes,
        Route_Risk_Category

    FROM vw_route_performance

    WHERE LOWER(
        TRIM(
            CAST(Route_Valid AS TEXT)
        )
    ) IN ('true', '1')
),

ranked_routes AS (

    SELECT
        Route,
        Total_Flights,
        On_Time_Rate_Percent,
        Delay_Rate_Percent,
        Average_Arrival_Delay_Minutes,
        Route_Risk_Category,

        RANK() OVER (
            ORDER BY
                Total_Flights DESC
        ) AS Volume_Rank,

        SUM(Total_Flights) OVER (
            ORDER BY
                Total_Flights DESC,
                Route

            ROWS BETWEEN
                UNBOUNDED PRECEDING
                AND CURRENT ROW
        ) AS Cumulative_Flights,

        SUM(Total_Flights) OVER ()
            AS All_Valid_Route_Flights

    FROM route_volume
)

SELECT
    Route,
    Total_Flights,
    Volume_Rank,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Average_Arrival_Delay_Minutes,
    Route_Risk_Category,
    Cumulative_Flights,
    All_Valid_Route_Flights,

    ROUND(
        100.0 *
        Cumulative_Flights
        /
        All_Valid_Route_Flights,
        2
    ) AS Cumulative_Flight_Share_Percent

FROM ranked_routes

ORDER BY
    Volume_Rank,
    Route

LIMIT 50;


-- ============================================================
-- 6. TOP AND BOTTOM ROUTES WITHIN EACH RISK CATEGORY
-- Uses PARTITION BY and ROW_NUMBER.
-- ============================================================

WITH ranked_risk_routes AS (

    SELECT
        Route,
        Total_Flights,
        On_Time_Rate_Percent,
        Delay_Rate_Percent,
        Average_Arrival_Delay_Minutes,
        Route_Risk_Category,

        ROW_NUMBER() OVER (
            PARTITION BY Route_Risk_Category

            ORDER BY
                Delay_Rate_Percent DESC,
                Average_Arrival_Delay_Minutes DESC,
                Total_Flights DESC
        ) AS Highest_Risk_Position,

        ROW_NUMBER() OVER (
            PARTITION BY Route_Risk_Category

            ORDER BY
                Delay_Rate_Percent ASC,
                Average_Arrival_Delay_Minutes ASC,
                Total_Flights DESC
        ) AS Lowest_Risk_Position

    FROM vw_route_performance

    WHERE LOWER(
        TRIM(
            CAST(Route_Valid AS TEXT)
        )
    ) IN ('true', '1')

      AND Total_Flights >= 10
)

SELECT
    Route,
    Total_Flights,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Average_Arrival_Delay_Minutes,
    Route_Risk_Category,

    CASE
        WHEN Highest_Risk_Position <= 3
        THEN 'Highest Delay Group'

        WHEN Lowest_Risk_Position <= 3
        THEN 'Lowest Delay Group'

        ELSE 'Other'
    END AS Category_Position

FROM ranked_risk_routes

WHERE Highest_Risk_Position <= 3
   OR Lowest_Risk_Position <= 3

ORDER BY
    CASE Route_Risk_Category
        WHEN 'High Risk' THEN 1
        WHEN 'Moderate Risk' THEN 2
        WHEN 'Low Risk' THEN 3
        ELSE 4
    END,

    CASE Category_Position
        WHEN 'Highest Delay Group' THEN 1
        WHEN 'Lowest Delay Group' THEN 2
        ELSE 3
    END,

    Delay_Rate_Percent DESC;


-- ============================================================
-- 7. AIRPORT PERFORMANCE PERCENTILE GROUPS
-- Uses NTILE to divide origin airports into four groups.
-- ============================================================

WITH origin_airport_metrics AS (

    SELECT
        Airport_Code,
        Airport_City,
        Airport_State,
        Total_Flight_Records,
        On_Time_Rate_Percent,
        Delay_Rate_Percent,
        Average_Departure_Delay_Minutes,
        Average_Arrival_Delay_Minutes

    FROM vw_airport_performance

    WHERE Airport_Role = 'Origin'
      AND Total_Flight_Records >= 100
),

airport_quartiles AS (

    SELECT
        Airport_Code,
        Airport_City,
        Airport_State,
        Total_Flight_Records,
        On_Time_Rate_Percent,
        Delay_Rate_Percent,
        Average_Departure_Delay_Minutes,
        Average_Arrival_Delay_Minutes,

        NTILE(4) OVER (
            ORDER BY
                On_Time_Rate_Percent DESC,
                Average_Departure_Delay_Minutes ASC
        ) AS Performance_Quartile

    FROM origin_airport_metrics
)

SELECT
    Airport_Code,
    Airport_City,
    Airport_State,
    Total_Flight_Records,
    On_Time_Rate_Percent,
    Delay_Rate_Percent,
    Average_Departure_Delay_Minutes,
    Average_Arrival_Delay_Minutes,
    Performance_Quartile,

    CASE Performance_Quartile
        WHEN 1 THEN 'Top Performance Quartile'
        WHEN 2 THEN 'Above Average Quartile'
        WHEN 3 THEN 'Below Average Quartile'
        WHEN 4 THEN 'Lowest Performance Quartile'
        ELSE 'Unknown'
    END AS Performance_Group

FROM airport_quartiles

ORDER BY
    Performance_Quartile,
    On_Time_Rate_Percent DESC;


-- ============================================================
-- 8. DELAY-SEVERITY CONTRIBUTION BY AIRLINE
-- Measures each airline's share of severe and extreme delays.
-- ============================================================

WITH airline_delay_severity AS (

    SELECT
        Airline_Code,
        Airline_Name,

        COUNT(*) AS Total_Flights,

        SUM(
            CASE
                WHEN Delay_Severity = 'Severe Delay'
                THEN 1
                ELSE 0
            END
        ) AS Severe_Delay_Flights,

        SUM(
            CASE
                WHEN Delay_Severity = 'Extreme Delay'
                THEN 1
                ELSE 0
            END
        ) AS Extreme_Delay_Flights

    FROM vw_flight_analysis

    GROUP BY
        Airline_Code,
        Airline_Name
),

delay_totals AS (

    SELECT
        SUM(Severe_Delay_Flights)
            AS All_Severe_Delays,

        SUM(Extreme_Delay_Flights)
            AS All_Extreme_Delays

    FROM airline_delay_severity
)

SELECT
    a.Airline_Code,
    a.Airline_Name,
    a.Total_Flights,
    a.Severe_Delay_Flights,
    a.Extreme_Delay_Flights,

    ROUND(
        100.0 *
        a.Severe_Delay_Flights
        /
        NULLIF(d.All_Severe_Delays, 0),
        2
    ) AS Share_of_All_Severe_Delays_Percent,

    ROUND(
        100.0 *
        a.Extreme_Delay_Flights
        /
        NULLIF(d.All_Extreme_Delays, 0),
        2
    ) AS Share_of_All_Extreme_Delays_Percent,

    ROUND(
        100.0 *
        (
            a.Severe_Delay_Flights
            +
            a.Extreme_Delay_Flights
        )
        /
        a.Total_Flights,
        2
    ) AS Severe_or_Extreme_Delay_Rate

FROM airline_delay_severity AS a

CROSS JOIN delay_totals AS d

ORDER BY
    Severe_or_Extreme_Delay_Rate DESC,
    a.Airline_Name;