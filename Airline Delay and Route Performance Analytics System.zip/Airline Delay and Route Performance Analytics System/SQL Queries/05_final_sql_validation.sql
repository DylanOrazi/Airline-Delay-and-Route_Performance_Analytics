-- ============================================================
-- AIRLINE DELAY AND ROUTE PERFORMANCE ANALYTICS SYSTEM
-- FINAL SQL VALIDATION
-- File: 05_final_sql_validation.sql
-- ============================================================


-- ============================================================
-- 1. CONFIRM THE MAIN TABLE EXISTS
-- ============================================================

SELECT
    name AS Table_Name,
    type AS Object_Type
FROM sqlite_master
WHERE type = 'table'
  AND name = 'flights';


-- ============================================================
-- 2. CONFIRM ALL REQUIRED VIEWS EXIST
-- ============================================================

SELECT
    name AS View_Name
FROM sqlite_master
WHERE type = 'view'
  AND name IN (
      'vw_flight_analysis',
      'vw_airline_performance',
      'vw_airport_performance',
      'vw_route_performance'
  )
ORDER BY name;


-- ============================================================
-- 3. COUNT REQUIRED VIEWS
-- Expected result: 4
-- ============================================================

SELECT
    COUNT(*) AS Required_View_Count
FROM sqlite_master
WHERE type = 'view'
  AND name IN (
      'vw_flight_analysis',
      'vw_airline_performance',
      'vw_airport_performance',
      'vw_route_performance'
  );


-- ============================================================
-- 4. VALIDATE MAIN TABLE RECORD COUNT
-- Expected result: 7,965
-- ============================================================

SELECT
    COUNT(*) AS Flights_Table_Record_Count
FROM flights;


-- ============================================================
-- 5. VALIDATE FLIGHT ANALYSIS VIEW RECORD COUNT
-- Expected result: 7,965
-- ============================================================

SELECT
    COUNT(*) AS Flight_Analysis_View_Record_Count
FROM vw_flight_analysis;


-- ============================================================
-- 6. RECONCILE TABLE AND FLIGHT VIEW TOTALS
-- Expected difference: 0
-- ============================================================

SELECT
    (
        SELECT COUNT(*)
        FROM flights
    ) AS Flights_Table_Total,

    (
        SELECT COUNT(*)
        FROM vw_flight_analysis
    ) AS Flight_View_Total,

    (
        SELECT COUNT(*)
        FROM flights
    )
    -
    (
        SELECT COUNT(*)
        FROM vw_flight_analysis
    ) AS Record_Count_Difference;


-- ============================================================
-- 7. CHECK FOR DUPLICATE FLIGHT IDS
-- Expected duplicate records: 5
-- ============================================================

SELECT
    COUNT(*) AS Total_Records,
    COUNT(DISTINCT Flight_ID) AS Unique_Flight_IDs,

    COUNT(*)
    -
    COUNT(DISTINCT Flight_ID)
        AS Duplicate_Flight_ID_Records

FROM flights;


-- ============================================================
-- 8. VERIFY STATUS TOTALS
-- Recognized status total should equal total records.
-- ============================================================

SELECT
    COUNT(*) AS Total_Records,

    SUM(
        CASE
            WHEN Flight_Status = 'On Time'
            THEN 1
            ELSE 0
        END
    ) AS On_Time_Records,

    SUM(
        CASE
            WHEN Flight_Status = 'Delayed'
            THEN 1
            ELSE 0
        END
    ) AS Delayed_Records,

    SUM(
        CASE
            WHEN Flight_Status = 'Cancelled'
            THEN 1
            ELSE 0
        END
    ) AS Cancelled_Records,

    SUM(
        CASE
            WHEN Flight_Status = 'Diverted'
            THEN 1
            ELSE 0
        END
    ) AS Diverted_Records,

    SUM(
        CASE
            WHEN Flight_Status IN (
                'On Time',
                'Delayed',
                'Cancelled',
                'Diverted'
            )
            THEN 1
            ELSE 0
        END
    ) AS Recognized_Status_Total

FROM flights;


-- ============================================================
-- 9. CHECK FOR UNEXPECTED STATUS VALUES
-- Expected result: no rows
-- ============================================================

SELECT
    Flight_Status,
    COUNT(*) AS Flight_Count
FROM flights
WHERE Flight_Status IS NULL
   OR TRIM(Flight_Status) = ''
   OR Flight_Status NOT IN (
       'On Time',
       'Delayed',
       'Cancelled',
       'Diverted'
   )
GROUP BY Flight_Status;


-- ============================================================
-- 10. RECONCILE AIRLINE VIEW TOTALS
-- Expected result: 7,965
-- ============================================================

SELECT
    SUM(Total_Flights)
        AS Airline_View_Summarized_Flights
FROM vw_airline_performance;


-- ============================================================
-- 11. RECONCILE ROUTE VIEW TOTALS
-- Expected result: 7,965
-- ============================================================

SELECT
    SUM(Total_Flights)
        AS Route_View_Summarized_Flights
FROM vw_route_performance;


-- ============================================================
-- 12. RECONCILE AIRPORT VIEW TOTALS
-- Flights appear once as an origin and once as a destination.
-- Expected result: 15,930
-- ============================================================

SELECT
    SUM(Total_Flight_Records)
        AS Airport_View_Activity_Records
FROM vw_airport_performance;


-- ============================================================
-- 13. VERIFY AIRLINE COUNT
-- Expected result: approximately 10
-- ============================================================

SELECT
    COUNT(*) AS Airline_Count
FROM vw_airline_performance;


-- ============================================================
-- 14. VERIFY DISTINCT ROUTE COUNT
-- ============================================================

SELECT
    COUNT(DISTINCT Route)
        AS Distinct_Routes_From_Table,

    (
        SELECT COUNT(*)
        FROM vw_route_performance
    ) AS Route_View_Row_Count

FROM flights;


-- ============================================================
-- 15. CHECK INVALID ROUTE RECORDS
-- ============================================================

SELECT
    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(Route_Valid AS TEXT)
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS Invalid_Route_Records
FROM flights;


-- ============================================================
-- 16. CHECK INVALID CANCELLATION CODE RECORDS
-- ============================================================

SELECT
    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Cancellation_Code_Valid AS TEXT
                    )
                )
            ) IN ('false', '0')
            THEN 1
            ELSE 0
        END
    ) AS Invalid_Cancellation_Code_Records
FROM flights;


-- ============================================================
-- 17. CHECK DELAY OUTLIER RECORDS
-- ============================================================

SELECT
    SUM(
        CASE
            WHEN LOWER(
                TRIM(
                    CAST(
                        Delay_Outlier_Flag AS TEXT
                    )
                )
            ) IN ('true', '1')
            THEN 1
            ELSE 0
        END
    ) AS Delay_Outlier_Records
FROM flights;


-- ============================================================
-- 18. VERIFY MONTH VALUES
-- Expected result: months 1 through 12
-- ============================================================

SELECT
    CAST(Month AS INTEGER) AS Month_Number,
    COUNT(*) AS Flight_Count
FROM flights
GROUP BY CAST(Month AS INTEGER)
ORDER BY CAST(Month AS INTEGER);


-- ============================================================
-- 19. VERIFY ANALYTICAL CATEGORY VALUES
-- ============================================================

SELECT
    Route_Risk_Category,
    COUNT(*) AS Flight_Count
FROM flights
GROUP BY Route_Risk_Category
ORDER BY Flight_Count DESC;


-- ============================================================
-- 20. VERIFY DELAY SEVERITY VALUES
-- ============================================================

SELECT
    Delay_Severity,
    COUNT(*) AS Flight_Count
FROM flights
GROUP BY Delay_Severity
ORDER BY Flight_Count DESC;


-- ============================================================
-- 21. VERIFY DISTANCE CATEGORY VALUES
-- ============================================================

SELECT
    Distance_Category,
    COUNT(*) AS Flight_Count
FROM flights
GROUP BY Distance_Category
ORDER BY Flight_Count DESC;


-- ============================================================
-- 22. VERIFY DEPARTURE TIME CATEGORY VALUES
-- ============================================================

SELECT
    Departure_Time_Category,
    COUNT(*) AS Flight_Count
FROM flights
GROUP BY Departure_Time_Category
ORDER BY Flight_Count DESC;


-- ============================================================
-- 23. VERIFY SEASON VALUES
-- ============================================================

SELECT
    Season,
    COUNT(*) AS Flight_Count
FROM flights
GROUP BY Season
ORDER BY Flight_Count DESC;


-- ============================================================
-- 24. FINAL DATABASE SUMMARY
-- ============================================================

SELECT
    COUNT(*) AS Total_Flights,
    COUNT(DISTINCT Flight_ID) AS Unique_Flight_IDs,
    COUNT(DISTINCT Airline_Code) AS Airlines,
    COUNT(DISTINCT Origin_Airport) AS Origin_Airports,
    COUNT(DISTINCT Destination_Airport)
        AS Destination_Airports,
    COUNT(DISTINCT Route) AS Routes,
    MIN(Flight_Date) AS Earliest_Flight_Date,
    MAX(Flight_Date) AS Latest_Flight_Date
FROM flights;